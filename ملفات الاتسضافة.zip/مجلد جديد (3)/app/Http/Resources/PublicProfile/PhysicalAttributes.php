<?php

namespace App\Http\Resources\PublicProfile;

use Illuminate\Http\Resources\Json\JsonResource;

class PhysicalAttributes extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $lang = $request->header('Accept-Language') ?? $request->header('app_language') ?? $request->get('lang') ?? 'ar';

        $cleanBodyType = $this->body_type;
        if (in_array(trim($cleanBodyType), ['ارسل رسالة الان', 'ارسل رسالة الآن', '_', '___', '-'])) {
            $cleanBodyType = '';
        }

        return [
            'height'      => $this->height,
            'weight'      => $this->weight,
            'eye_color'   => function_exists('translate') ? translate($this->eye_color, $lang) : $this->eye_color,
            'hair_color'  => function_exists('translate') ? translate($this->hair_color, $lang) : $this->hair_color,
            'complexion'  => function_exists('translate') ? translate($this->complexion, $lang) : $this->complexion,
            'blood_group' => $this->blood_group,
            'body_type'   => function_exists('translate') ? translate($cleanBodyType, $lang) : $cleanBodyType,
            'body_art'    => function_exists('translate') ? translate($this->body_art, $lang) : $this->body_art,
            'disability'  => function_exists('translate') ? translate($this->disability, $lang) : $this->disability,
        ];
    }
}