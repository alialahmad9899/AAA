<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PartnerExpectationRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'general'                      => ['nullable', 'string'],
            'partner_height'               => ['nullable'],
            'partner_weight'               => ['nullable'],
            'partner_marital_status'       => ['nullable'],
            'partner_children_acceptable'  => ['nullable', 'string', 'max:20'],
            'residence_country_id'         => ['nullable'],
            'partner_religion_id'          => ['nullable'],
            'smoking_acceptable'           => ['nullable', 'string', 'max:20'],
            'drinking_acceptable'          => ['nullable', 'string', 'max:20'],
            'partner_diet'                 => ['nullable', 'string', 'max:50'],
            'partner_manglik'              => ['nullable', 'string', 'max:50'],
            'language_id'                  => ['nullable'],
            'partner_country_id'           => ['nullable'],
            'partner_state_id'             => ['nullable'],
            'pertner_complexion'           => ['nullable', 'string', 'max:50'],
            'partner_complexion'           => ['nullable', 'string', 'max:50'],
            'partner_education'            => ['nullable', 'string'],
            'pertner_education'            => ['nullable', 'string'],
            'partner_profession'           => ['nullable', 'string'],
        ];
    }
}