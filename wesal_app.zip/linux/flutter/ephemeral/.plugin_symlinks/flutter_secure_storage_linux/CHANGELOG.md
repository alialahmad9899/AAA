## 1.2.3
- Adds application ID to cmake file

## 1.2.2
- Fix json.dump with indentations 

## 1.2.1
- Fixed search with schemas fails in cold keyrings
- Fixed erase called on null

## 1.2.0
- Remove and replace libjsoncpp1 dependency
- Update Dart SDK Constraint to support <4.0.0 instead of <3.0.0.

## 1.1.3
Fixed a memory management issue

## 1.1.2
Updated flutter_secure_storage_platform_interface to latest version.

## 1.1.1
Fixed an issue where no error was being reported if there was something wrong accessing the secret service.

## 1.1.0
Add containsKey function.

## 1.0.0
- Initial Linux implementation
- Removed unused Flutter test and effective_dart dependency