import 'package:flutter_test/flutter_test.dart';
import 'package:wesal_app/models/member_profile_model.dart';

void main() {
  group('AttributeTranslator Tests', () {
    test('cleanEmojis removes all emojis and normalizes spaces', () {
      expect(AttributeTranslator.cleanEmojis('أعزب / عزباء 💍'), 'أعزب / عزباء');
      expect(AttributeTranslator.cleanEmojis('Single 💍'), 'Single');
      expect(AttributeTranslator.cleanEmojis('  لا أدخن أبداً 🌿  '), 'لا أدخن أبداً');
    });

    test('isValidValue filters invalid placeholders', () {
      expect(AttributeTranslator.isValidValue(null), false);
      expect(AttributeTranslator.isValidValue(''), false);
      expect(AttributeTranslator.isValidValue('---'), false);
      expect(AttributeTranslator.isValidValue('null'), false);
      expect(AttributeTranslator.isValidValue('ارسل رسالة'), false);
      expect(AttributeTranslator.isValidValue('مهندس'), true);
    });

    test('translateMaritalStatus works for both AR and EN', () {
      expect(AttributeTranslator.translateMaritalStatus('1', isArabic: true), 'أعزب / عزباء 💍');
      expect(AttributeTranslator.translateMaritalStatus('1', isArabic: false), 'Single 💍');
      expect(AttributeTranslator.translateMaritalStatus('2', isArabic: true), 'متزوج / متزوجة 💍');
      expect(AttributeTranslator.translateMaritalStatus('3', isArabic: false), 'Divorced 💍');
    });

    test('translateReligion works correctly', () {
      expect(AttributeTranslator.translateReligion('1', isArabic: true), 'إسلام ☪️');
      expect(AttributeTranslator.translateReligion('1', isArabic: false), 'Islam ☪️');
      expect(AttributeTranslator.translateReligion('2', isArabic: true), 'مسيحية ✝️');
      expect(AttributeTranslator.translateReligion('2', isArabic: false), 'Christianity ✝️');
    });
  });

  group('MemberProfileModel Parsing Test', () {
    test('MemberProfileModel parses basic info correctly', () {
      final json = {
        'id': 105,
        'user_id': 105,
        'introduction': 'مرحباً بكم في ملفي الشخصي',
        'basic_info': {
          'first_name': 'أحمد',
          'last_name': 'العلي',
          'gender': '1',
          'phone': '0912345678',
          'date_of_birth': '1995-05-15',
          'marital_status': '1',
          'religion': '1',
        },
        'physical_attributes': {
          'height': '1.80',
          'weight': '75',
          'eye_color': 'بني',
          'hair_color': 'أسود',
        }
      };

      final profile = MemberProfileModel.fromJson(json);

      expect(profile.userId, 105);
      expect(profile.introduction, 'مرحباً بكم في ملفي الشخصي');
      expect(profile.basicInfo.firstName, 'أحمد');
      expect(profile.basicInfo.lastName, 'العلي');
      expect(profile.basicInfo.gender, '1');
      expect(profile.basicInfo.isFemale, false);
      expect(profile.physicalAttributes?.height, '1.80');
      expect(profile.physicalAttributes?.weight, '75');
    });
  });
}
