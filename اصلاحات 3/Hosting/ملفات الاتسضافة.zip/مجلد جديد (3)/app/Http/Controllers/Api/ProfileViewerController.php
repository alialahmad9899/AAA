<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Api\Controller;
use App\Http\Resources\MyProfileViewerResource;
use App\Models\ProfileViewer;
use App\Utility\NotificationUtility;
use Illuminate\Http\Request;

class ProfileViewerController extends Controller
{
    /**
     * 🟢 1. جلب قائمة الأعضاء الذين زاروا بروفايل المستخدم الحالي
     * دعم الصلاحيات والسقف الديناميكي للباقة المفعلة فعلياً
     */
    public function my_profile_viewers()
    {
        $user = auth()->user();

        // 1. فحص جنس المستخدم (إناث / ذكور) بدقة لجميع حالات التخزين في قاعدة البيانات
        $genderStr = strtolower(trim($user->gender ?? ''));
        $memberGender = $user->member->gender ?? null;
        $isFemale = $genderStr == 'female' 
            || str_contains($genderStr, 'أنثى') 
            || str_contains($genderStr, 'انثى')
            || $memberGender == 2 
            || $memberGender == '2';

        // 2. فحص حالة الاشتراك النشط وتاريخ صلاحية الباقة
        $isSubscribed = $user->membership == 2 || ($user->member && !empty($user->member->package_validity) && $user->member->package_validity >= date('Y-m-d'));

        // 3. قراءة عدد الزوار المتاح في الباقة الحالية للعضو من جدول member
        $packageQuota = (int) ($user->member->remaining_profile_viewer_view ?? 0);

        // 4. تحديد سقف العرض الفعلي القادم من الباقة المفعلة:
        // - الإناث: مفتوح بلا حدود (9999)
        // - الذكور المشتركون: سقف الباقة المفعلة فعلياً (أو 50 كحد افتراضي للباقات)
        // - الذكور غير المشتركين (الحساب المجاني): 3 مشاهدات فقط
        if ($isFemale) {
            $allowedLimit = 9999;
        } elseif ($isSubscribed) {
            $allowedLimit = $packageQuota > 0 ? $packageQuota : 50;
        } else {
            $allowedLimit = 3;
        }

        // 5. جلب قائمة الزوار النشطين والمفعلين مرتبة حسب الأحدث
        $profileViewers = ProfileViewer::where('user_id', $user->id)
            ->whereIn("viewed_by", function ($query) {
                $query->select('id')
                    ->from('users')
                    ->where('approved', '1')
                    ->where('blocked', 0)
                    ->where('deactivated', 0)
                    ->where('permanently_delete', 0);
            })
            ->orderBy('updated_at', 'desc')
            ->paginate(15);

        // 6. إرجاع النتيجة مع قيم السيرفر الديناميكية لتطبيق الموبايل
        return MyProfileViewerResource::collection($profileViewers)->additional([
            'result' => true,
            'status' => 'success',
            'package_limit' => $allowedLimit,        // سقف المشاهدات للباقة الحالية
            'remaining_quota' => $packageQuota,      // الرصيد المتبقي للباقة
            'is_subscribed' => $isSubscribed || $isFemale,
            'is_female' => $isFemale,
        ]);
    }

    /**
     * 🟢 2. تسجيل زيارة جديدة لملف شخصي وإرسال إشعار فوري FCM للعضو المَزار
     */
    public function record_profile_view(Request $request)
    {
        $request->validate([
            'user_id' => 'required|integer|exists:users,id'
        ]);

        $viewerId = auth()->id();
        $targetUserId = (int) $request->user_id;

        // عدم تسجيل الزيارة إذا كان المستخدم يتصفح ملفه الشخصي بنفسه
        if ($viewerId === $targetUserId) {
            return response()->json([
                'result' => false,
                'message' => 'Cannot record self profile view'
            ], 200);
        }

        // إنشاء أو تحديث توقيت الزيارة
        $viewerRecord = ProfileViewer::firstOrNew([
            'user_id' => $targetUserId,
            'viewed_by' => $viewerId,
        ]);

        $isNewVisit = !$viewerRecord->exists;
        $viewerRecord->updated_at = now();
        $viewerRecord->save();

        // إرسال إشعار فوري FCM للعضو المَزار
        try {
            $viewerUser = auth()->user();
            $viewerName = trim(($viewerUser->first_name ?? '') . ' ' . ($viewerUser->last_name ?? '')) ?: ($viewerUser->name ?? 'عضو في وصال');

            NotificationUtility::send_notification(
                $targetUserId,
                'profile_view',
                "قام $viewerName بزيارة ملفك الشخصي 👁️",
                "$viewerName viewed your profile 👁️",
                [
                    'type' => 'profile_view',
                    'viewer_id' => $viewerId,
                    'viewer_name' => $viewerName,
                    'viewer_photo' => $viewerUser->photo ?? '',
                ]
            );
        } catch (\Exception $e) {
            \Log::error("Profile view notification error: " . $e->getMessage());
        }

        return response()->json([
            'result' => true,
            'status' => 'success',
            'is_new_visit' => $isNewVisit,
            'message' => 'Profile view recorded successfully'
        ], 200);
    }
}