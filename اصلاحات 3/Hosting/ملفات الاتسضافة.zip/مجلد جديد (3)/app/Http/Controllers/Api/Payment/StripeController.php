<?php

namespace App\Http\Controllers\Api\Payment;

use App\Models\Package;
use Illuminate\Http\Request;
use App\Http\Controllers\Api\Controller;
use App\Http\Controllers\Api\PackageController;
use Stripe\Stripe;
use Stripe\PaymentIntent;

/**
 * 🟢 متحكم معالجة عمليات الدفع عبر بوابة Stripe
 */
class StripeController extends Controller
{
    /**
     * 🟢 1. إنشاء PaymentIntent للدفع المباشر داخل التطبيق (Native Payment Sheet)
     * 
     * @param Request $request يحتوي على package_id
     * @return \Illuminate\Http\JsonResponse
     */
    public function create_payment_intent(Request $request)
    {
        try {
            // أ) التحقق من وجود المعاملات المطلوبة في الطلب
            $request->validate([
                'package_id' => 'required|integer',
            ]);

            $packageId = $request->package_id;
            
            // ب) البحث عن الباقة في قاعدة البيانات
            $package = Package::find($packageId);

            if (!$package) {
                return response()->json([
                    'result'  => false,
                    'message' => 'عذراً، الباقة المطلوبة غير موجودة.'
                ], 404);
            }

            // ج) جلب مفاتيح Stripe بمان من الإعدادات أو البيئة
            $stripeSecret = config('services.stripe.secret') ?? env('STRIPE_SECRET');
            $stripePublishable = config('services.stripe.key') ?? env('STRIPE_KEY');

            if (empty($stripeSecret)) {
                return response()->json([
                    'result'  => false,
                    'message' => 'مفتاح STRIPE_SECRET غير معرف بملف .env بالسيرفر.'
                ], 500);
            }

            // د) إعداد مفتاح Stripe السري
            Stripe::setApiKey($stripeSecret);

            // هـ) تحديد معرف المستخدم الحاضر (سواء عبر Sanctum Token أو البيانات المرسلة)
            $userId = auth('sanctum')->id() ?? $request->user_id ?? 1265;

            // و) حساب المبلغ بالسنتات وتحويله لعدد صحيح صريح
            $amountInCents = (int) round($package->price * 100);

            // ز) إنشاء أمر الدفع (PaymentIntent) عبر مكتبة Stripe
            $paymentIntent = PaymentIntent::create([
                'amount' => $amountInCents,
                'currency' => 'usd',
                'payment_method_types' => ['card'], // حصر طريقة الدفع بالبطاقات المباشرة
                'metadata' => [
                    'user_id'    => $userId,
                    'package_id' => $packageId,
                ],
            ]);

            // ح) إعادة الاستجابة بنجاح مع إرسال client_secret و publishable_key
            return response()->json([
                'result'          => true,
                'status'          => 200,
                'client_secret'   => $paymentIntent->client_secret,
                'publishable_key' => $stripePublishable ?? '',
            ], 200);

        } catch (\Exception $e) {
            // ط) التعامل مع أي خطأ غير متوقع أثناء العملية
            return response()->json([
                'result'  => false,
                'message' => 'حدث خطأ أثناء إعداد عملية الدفع: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * 🟢 2. تأكيد نجاح العملية وتفعيل الباقة للمستخدم
     * 
     * @param Request $request يحتوي على package_id و amount
     * @return \Illuminate\Http\JsonResponse
     */
    public function success(Request $request)
    {
        try {
            // أ) جلب معرّف المستخدم
            $userId = auth('sanctum')->id() ?? $request->user_id ?? 1265;
            $packageId = $request->package_id;
            $amount = $request->amount;

            // ب) تجهيز بيانات عملية الدفع لتسجيلها
            $payment_data = [
                "package_id"     => $packageId,
                "payment_method" => 'stripe',
                "amount"         => $amount
            ];

            $paymentStatus = ["status" => "Success"];
            
            // ج) استدعاء متحكم الباقات لتفعيل الباقة وحفظ الشراء
            $packagePaymentController = new PackageController;
            $packagePaymentController->package_payment_done($userId, $payment_data, json_encode($paymentStatus));

            // د) إرجاع استجابة النجاح
            return response()->json([
                'result'  => true,
                'message' => 'تم الدفع وتفعيل الباقة بنجاح.'
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'result'  => false,
                'message' => 'فشلت معالجة تفعيل الباقة: ' . $e->getMessage()
            ], 500);
        }
    }
}