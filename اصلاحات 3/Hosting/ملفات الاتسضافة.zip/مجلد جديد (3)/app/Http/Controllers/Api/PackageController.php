<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Api\Controller;
use App\Http\Resources\PackagePaymentInvoiceResource;
use App\Http\Resources\PackagePaymentResource;
use App\Http\Resources\PackageResource;
use App\Models\ManualPaymentMethod;
use App\Models\Member;
use App\Models\Package;
use App\Models\PackagePayment;
use App\Models\User;
use App\Models\Wallet;
use App\Notifications\DbStoreNotification;
use App\Services\FirebaseNotificationService;
use App\Utility\EmailUtility;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Notification;

class PackageController extends Controller
{
    /**
     * 🟢 دالة مساعدة خاصة لاستخراج لغة الطلب الحقيقية من الرابط أو الترويسات بشكل مضمون
     */
    private function getRequestLanguage(Request $request): string
    {
        $lang = $request->query(
            'lang', 
            $request->header('Accept-Language', 
            $request->header('app_language', 
            $request->header('lang', 'ar')))
        );

        return (str_contains(strtolower($lang), 'en')) ? 'en' : 'ar';
    }

    /**
     * 🟢 دالة مساعدة لترجمة اسم الباقة مع خيار احتياطي مضمون (Fallback)
     */
    private function formatPackageName($package, string $lang): string
    {
        if ($lang === 'en') {
            if (!empty($package->name_en)) {
                return $package->name_en;
            }
            // تحويل احتياطي مباشر في حال كان الاسم المخزن بالعربية فقط
            $rawName = $package->name ?? '';
            if (str_contains($rawName, 'الأسبوعي') || str_contains($rawName, 'اسبوعي')) {
                return 'Weekly Subscription';
            }
            if (str_contains($rawName, 'الشهري') || str_contains($rawName, 'شهري')) {
                return 'Monthly Subscription';
            }
            if (str_contains($rawName, '3') || str_contains($rawName, 'ثلاثة')) {
                return '3-Month Subscription';
            }
            if (str_contains($rawName, 'الأساسية') || str_contains($rawName, 'اساسية')) {
                return 'Basic Package';
            }
        }

        return $package->name ?? '';
    }

    /**
     * 🟢 1. جلب طرق الدفع اليدوية (مثل الشام كاش) لتطبيق Flutter مع دعم التدويل
     */
    public function manual_payment_methods(Request $request)
    {
        $lang = $this->getRequestLanguage($request);
        $methods = ManualPaymentMethod::all()->map(function ($method) use ($lang) {
            return [
                'id'          => $method->id,
                'heading'     => ($lang === 'en' && !empty($method->heading_en)) ? $method->heading_en : $method->heading,
                'description' => ($lang === 'en' && !empty($method->description_en)) ? $method->description_en : $method->description,
                'code'        => $method->code ?? '',
            ];
        });

        return response()->json([
            'result' => true,
            'data'   => $methods
        ], 200);
    }

    /**
     * 🟢 2. جلب الباقات المتاحة مع الترجمة الديناميكية (عربي / إنجليزي)
     */
    public function active_packages(Request $request)
    {
        $user = auth()->user();
        $lang = $this->getRequestLanguage($request);

        // إذا كانت المستخدمة أنثى -> إرجاع تنبيه بأن الحساب مجاني بالكامل
        if ($user && (strtolower($user->gender) == 'female' || $user->gender == 'أنثى' || $user->gender == 'انثى')) {
            $freeMessage = ($lang === 'en')
                ? 'Female accounts are completely free and support all features forever.'
                : 'حساب الإناث مجاني بالكامل ويدعم كافة الميزات مجاناً ودائماً.';

            return response()->json([
                'result'  => true,
                'is_free' => true,
                'message' => $freeMessage,
                'data'    => []
            ], 200);
        }

        // للذكور -> إرجاع الباقات النشطة مع تحديد الاسم بحسب اللغة بأسلوب مضمون
        $packages = Package::where('active', '1')->get()->map(function ($package) use ($lang) {
            return [
                'id'                   => $package->id,
                'name'                 => $this->formatPackageName($package, $lang),
                'name_ar'              => $package->name,
                'name_en'              => $package->name_en ?? '',
                'price'                => $package->price,
                'validity'             => $package->validity,
                'express_interest'     => $package->express_interest,
                'photo_gallery'        => $package->photo_gallery,
                'contact'              => $package->contact,
                'profile_viewers_view' => $package->profile_viewers_view,
                'profile_image_view'   => $package->profile_image_view,
                'gallery_image_view'   => $package->gallery_image_view,
            ];
        });

        return response()->json([
            'result'  => true,
            'is_free' => false,
            'data'    => $packages
        ], 200);
    }

    /**
     * 🟢 3. عرض تفاصيل باقة محددة مترجمة
     */
    public function package_details(Request $request)
    {
        $lang = $this->getRequestLanguage($request);
        $package = Package::find($request->package_id);

        if ($package) {
            $formattedPackage = [
                'id'                   => $package->id,
                'name'                 => $this->formatPackageName($package, $lang),
                'name_ar'              => $package->name,
                'name_en'              => $package->name_en ?? '',
                'price'                => $package->price,
                'validity'             => $package->validity,
                'express_interest'     => $package->express_interest,
                'photo_gallery'        => $package->photo_gallery,
                'contact'              => $package->contact,
                'profile_viewers_view' => $package->profile_viewers_view,
                'profile_image_view'   => $package->profile_image_view,
                'gallery_image_view'   => $package->gallery_image_view,
            ];

            return response()->json([
                'result' => true,
                'data'   => $formattedPackage
            ], 200);
        }

        $errorMessage = ($lang === 'en') ? 'Sorry!!, Invalid Data.' : 'عفواً، البيانات غير صالحة.';
        return $this->failure_message($errorMessage);
    }

    /**
     * 🟢 4. سجل عمليات شراء الباقات للمستخدم
     */
    public function package_purchase_history()
    {
        $package_payments = PackagePayment::latest()
            ->where('user_id', auth()->user()->id)
            ->paginate(10);

        return PackagePaymentResource::collection($package_payments)->additional([
            'result' => true
        ]);
    }

    /**
     * 🟢 5. فاتورة شراء الباقة
     */
    public function package_purchase_history_invoice(Request $request)
    {
        $lang = $this->getRequestLanguage($request);
        $payment = PackagePayment::find($request->package_payment_id);

        if ($payment) {
            return (new PackagePaymentInvoiceResource($payment))->additional([
                'result' => true
            ]);
        }

        $errorMessage = ($lang === 'en') ? 'Sorry!!, Invalid Data.' : 'عفواً، البيانات غير صالحة.';
        return $this->failure_message($errorMessage);
    }

    /**
     * 🟢 6. تقديم طلب شراء باقة (المحفظة أو الدفع اليدوي/الشام كاش)
     */
    public function package_purchase(Request $request)
    {
        $user = auth()->user();
        $lang = $this->getRequestLanguage($request);

        $payment_type = 'package_payment';
        $payment_data = array();
        $payment_data['package_id']     = $request->package_id;
        $payment_data['amount']         = $request->amount;
        $payment_data['payment_method'] = $request->payment_method;
        $payment_data['payment_type']   = $payment_type;

        // 1. الدفع عبر المحفظة الداخلية
        if ($request->payment_method == 'wallet') {
            if ($user->balance < $request->amount) {
                $noBalanceMsg = ($lang === 'en') ? 'You do not have enough balance.' : 'رصيدك غير كافٍ لإتمام العملية.';
                return $this->failure_message($noBalanceMsg);
            } else {
                $user->balance = $user->balance - $request->amount;
                $user->save();
                return $this->package_payment_done($user->id, $payment_data, null, $lang);
            }
        } 
        // 2. الدفع اليدوي / أوفلاين (الشام كاش)
        elseif ($request->payment_method == 'manual_payment') {
            $payment_proof = null;
            if ($request->hasFile('payment_proof')) {
                $payment_proof = upload_api_file($request->file('payment_proof'));
            }

            $manualMethod = ManualPaymentMethod::find($request->manual_payment_id);

            $package_payment = new PackagePayment();
            $package_payment->payment_code                    = date('ymd-His');
            $package_payment->user_id                         = $user->id;
            $package_payment->package_id                      = $request->package_id;
            $package_payment->payment_method                  = 'manual_payment';
            $package_payment->payment_status                  = 'Due'; // ينتظر موافقة الأدمن
            $package_payment->amount                          = $request->amount;
            $package_payment->payment_details                 = '';
            $package_payment->offline_payment                 = 1;
            $package_payment->custom_payment_name             = $manualMethod ? $manualMethod->heading : 'الشام كاش / دفع يدوي';
            $package_payment->custom_payment_transaction_id = $request->transaction_id;
            $package_payment->custom_payment_proof           = $payment_proof;
            $package_payment->custom_payment_details         = $request->payment_details;
            $package_payment->save();

            // إرسال إشعار للإدارة عند تقديم طلب الدفع اليدوي
            try {
                $notify_type  = 'admin_alert';
                $id           = unique_notify_id();
                $notify_by    = $user->id;
                $info_id      = $package_payment->id;
                $admin_title  = "طلب شراء باقة جديد (الشام كاش)";
                $message      = "قام العضو " . $user->first_name . ' ' . $user->last_name . " بتقديم طلب شراء باقة جديدة عبر الشام كاش. رمز الدفع: " . $package_payment->payment_code;
                $route        = route('package-payments.index');

                if (get_setting('firebase_push_notification') == 1) {
                    $adminTokens = User::where('user_type', 'admin')
                        ->whereNotNull('fcm_token')
                        ->pluck('fcm_token');
                    foreach ($adminTokens as $adminToken) {
                        FirebaseNotificationService::sendPushNotification(
                            $adminToken,
                            $admin_title,
                            $message,
                            [
                                'type'    => $notify_type,
                                'info_id' => $info_id,
                                'route'   => $route
                            ]
                        );
                    }
                }
                
                $adminUser = User::where('user_type', 'admin')->first();
                if ($adminUser) {
                    Notification::send($adminUser, new DbStoreNotification($notify_type, $id, $notify_by, $info_id, $message, $route, $admin_title));
                }
            } catch (\Exception $e) {
                // تجنب توقف العملية في حال وجود خلل بالإشعارات
            }

            if ($user->email != null && get_email_template('package_purchase_email', 'status')) {
                EmailUtility::package_purchase_email($user, $package_payment);
            }

            $successMsg = ($lang === 'en')
                ? 'Sham Cash payment request received successfully and is being reviewed by administration.'
                : 'تم استلام طلب الشراء عبر الشام كاش بنجاح، وجاري مراجعته من قبل الإدارة';

            return response()->json([
                'result'  => true, 
                'message' => $successMsg
            ], 200);
        }
    }

    /**
     * 🟢 7. تفعيل الباقة عند الشراء وتحديث الحصص والصلاحيات للمستخدم
     */
    public function package_payment_done($user_id, $payment_data, $payment_details, $lang = 'ar')
    {
        $user = User::where('id', $user_id)->first();

        $package_payment                  = new PackagePayment();
        $package_payment->payment_code    = date('ymd-His');
        $package_payment->user_id         = $user->id;
        $package_payment->package_id      = $payment_data['package_id'];
        $package_payment->payment_method  = $payment_data['payment_method'];
        $package_payment->payment_status  = 'Paid';
        $package_payment->amount          = $payment_data['amount'];
        $package_payment->payment_details = $payment_details;
        $package_payment->offline_payment = 2;
        $package_payment->save();

        $member  = Member::where('user_id', $user->id)->first();
        $package = Package::where('id', $payment_data['package_id'])->first();
        
        // 1. ربط الباقة المشتراة
        $member->current_package_id = $package->id;
        
        // 2. إعجابات/اهتمامات غير محدودة (-1)
        $member->remaining_interest = -1; 
        
        // 3. إضافة حصة مشاهدات زوار البروفايل المحددة للباقة
        $viewers_quota = $package->profile_viewers_view ?? 0;
        $member->remaining_profile_viewer_view = $member->remaining_profile_viewer_view + $viewers_quota;
        
        // 4. تفعيل البحث حسب التطابق
        $member->auto_profile_match = 1;

        // 5. احتساب تاريخ انتهاء الباقة بناءً على عدد أيام الصلاحية
        $base_date = ($member->package_validity && strtotime($member->package_validity) > strtotime(date('Y-m-d'))) 
            ? $member->package_validity 
            : date('Y-m-d');

        $member->package_validity = date('Y-m-d', strtotime($base_date . ' +' . $package->validity . ' days'));

        if ($member->save()) {
            $user->membership = 2; // عضو مميز
            $user->save();

            // معالجة عمولة الإحالة (Referral System)
            if (addon_activation('referral_system') && $user->referred_by != null && $user->referral_comission == 0) {
                $reffered_by = User::where('id', $user->referred_by)->first();
                if ($reffered_by) {
                    $wallet                  = new Wallet();
                    $wallet->user_id         = $reffered_by->id;
                    $wallet->amount          = get_setting('referred_by_user_commission');
                    $wallet->payment_method  = 'reffered_commission';
                    $wallet->payment_details = '';
                    $wallet->referral_user   = $user->id;
                    $wallet->save();

                    $reffered_by->balance = $reffered_by->balance + get_setting('referred_by_user_commission');
                    $reffered_by->save();

                    $user->referral_comission = 1;
                    $user->save();
                }
            }

            // إرسال الإشعارات للإدارة وللمستخدم
            try {
                $id        = unique_notify_id();
                $notify_by = $user->id;
                $info_id   = $package_payment->id;
                $route     = route('package-payments.index');
                
                $packageName = $this->formatPackageName($package, $lang);

                $admin_title   = "شراء باقة جديدة";
                $admin_message = "قام العضو " . $user->first_name . ' ' . $user->last_name . " بشراء باقة جديدة. رمز الدفع: " . $package_payment->payment_code;
                
                $client_title   = ($lang === 'en') ? "Package Activation" : "تفعيل الباقة";
                $client_message = ($lang === 'en')
                    ? "Package {$packageName} has been added successfully! You can now send messages and enjoy all app features."
                    : "تمت إضافة " . $package->name . " لحسابك بنجاح! يمكنك الآن المراسلة والاستفادة من كافة ميزات التطبيق فوراً.";

                if (get_setting('firebase_push_notification') == 1) {
                    $adminFcmTokens = User::where('user_type', 'admin')->whereNotNull('fcm_token')->pluck('fcm_token');
                    foreach ($adminFcmTokens as $admToken) {
                        FirebaseNotificationService::sendPushNotification($admToken, $admin_title, $admin_message, [
                            'type'    => 'admin_alert',
                            'info_id' => $info_id,
                            'route'   => $route
                        ]);
                    }

                    if (!empty($user->fcm_token)) {
                        FirebaseNotificationService::sendPushNotification($user->fcm_token, $client_title, $client_message, [
                            'type'    => 'package',
                            'info_id' => $package_payment->id,
                            'route'   => ''
                        ]);
                    }
                }

                $adminUser = User::where('user_type', 'admin')->first();
                if ($adminUser) {
                    Notification::send($adminUser, new DbStoreNotification('admin_alert', $id, $notify_by, $info_id, $admin_message, $route, $admin_title));
                }
                
                Notification::send($user, new DbStoreNotification('package', unique_notify_id(), $user->id, $package_payment->id, $client_message, '', $client_title));

            } catch (\Exception $e) {
                // تجنب توقف العملية في حال وجود خلل بالإشعارات
            }

            if ($user->email != null && get_email_template('package_purchase_email', 'status')) {
                EmailUtility::package_purchase_email($user, $package_payment);
            }
        }

        $activationMsg = ($lang === 'en') ? 'Package purchased and activated successfully!' : 'تمت عملية شراء وتفعيل الباقة بنجاح!';

        return response()->json([
            'result'  => true, 
            'message' => $activationMsg
        ], 200);
    }
}