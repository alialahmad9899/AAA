<?php

namespace App\Http\Controllers;

use App\Models\ManualPaymentMethod;
use App\Models\Member;
use App\Models\Package;
use App\Models\PackagePayment;
use App\Models\User;
use App\Models\Wallet;
use App\Models\Upload;
use App\Notifications\DbStoreNotification;
use App\Notifications\AdminActionNotification; 
use App\Services\FirebaseNotificationService;
use App\Utility\EmailUtility;
use App\Utility\SmsUtility;
use Auth;
use Illuminate\Http\Request;
use Notification;
use Session;

class PackagePaymentController extends Controller
{
    public function __construct()
    {
        $this->middleware(['permission:show_package_payments'])->only('index');
        $this->middleware(['permission:manage_package_manual_payemnts'])->only('show');
        $this->middleware(['permission:view_package_payment_invoice'])->only('package_payment_invoice_admin');
    }

    public function index(Request $request)
    {
        $payment_status = $request->payment_status;
        $per_page = 10;
        
        $package_payments = PackagePayment::orderBy('created_at', 'desc');
        
        if ($payment_status != null) {
            $package_payments = $package_payments->where('payment_status', $payment_status);
        }
        
        $package_payments = $package_payments->paginate($per_page);
        
        return view('admin.package_payments.index', compact('package_payments', 'payment_status', 'per_page'));
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        $user = Auth::user();
        $data['amount']         = $request->amount;
        $data['package_id']     = $request->package_id;
        $data['payment_method'] = $request->payment_option;

        $request->session()->put('payment_type', 'package_payment');
        $request->session()->put('payment_data', $data);

        if ($request->payment_option == 'paypal') {
            $paypal = new PaypalController();
            return $paypal->pay();
        } elseif ($request->payment_option == 'instamojo') {
            if (auth::user()->email) {
                $instamojo = new InstamojoController();
                return $instamojo->pay($request);
            } else {
                return redirect()->back()->with('error', 'Please add an email in your profile to continue with Instamojo.');
            }
        } elseif ($request->payment_option == 'stripe') {
            $stripe = new StripeController();
            return $stripe->pay();
        } elseif ($request->payment_option == 'razorpay') {
            $razorpay = new RazorpayController();
            return $razorpay->pay($request);
        } elseif ($request->payment_option == 'paystack') {
            $paystack = new PaystackController();
            return $paystack->redirectToGateway($request);
        } elseif ($request->payment_option == 'paytm') {
            $paytm = new PaytmController();
            return $paytm->index($request);
        } elseif ($request->payment_option == 'phonepe') {
            $phonepe = new PhonepeController();
            return $phonepe->pay($request);
        } elseif ($request->payment_option == 'wallet') {
            if ($user->balance < $request->amount) {
                flash(translate('You do not have enough balance.'))->error();
                return back();
            } else {
                $user->balance = $user->balance - $request->amount;
                $user->save();
                return $this->package_payment_done($request->session()->get('payment_data'), null);
            }
        } elseif ($request->payment_option == 'manual_payment') {
            $package_payment = new PackagePayment();
            $package_payment->payment_code = date('ymd-His');
            $package_payment->user_id = $user->id;
            $package_payment->package_id = $request->package_id;
            $package_payment->payment_method = 'manual_payment';
            $package_payment->payment_status = 'Due';
            $package_payment->amount = $request->amount;
            $package_payment->payment_details = '';
            $package_payment->offline_payment = 1;
            $package_payment->custom_payment_name = ManualPaymentMethod::find($request->manual_payment_id)->heading ?? 'دفع يدوي';
            $package_payment->custom_payment_transaction_id = $request->transaction_id;
            
            if ($request->hasFile('payment_proof')) {
                try {
                    $file = $request->file('payment_proof');
                    $extension = $file->getClientOriginalExtension();
                    $filename = time() . '_' . rand(1000, 9999) . '.' . $extension;
                    
                    $path = public_path('uploads/all');
                    if (!file_exists($path)) {
                        mkdir($path, 0777, true);
                    }
                    
                    $file->move($path, $filename);
                    
                    $upload = new Upload();
                    $upload->file_original_name = 'payment_proof'; 
                    $upload->file_name = 'uploads/all/' . $filename;
                    $upload->user_id = $user->id; 
                    $upload->extension = $extension;
                    $upload->file_size = filesize(public_path('uploads/all/' . $filename));
                    $upload->type = 'image';
                    $upload->save();
                    
                    $package_payment->custom_payment_proof = $upload->id;
                    
                } catch (\Exception $e) {
                    flash('عذراً، حدث خطأ أثناء رفع الصورة: ' . $e->getMessage())->error();
                    return back();
                }
            } else {
                $package_payment->custom_payment_proof = $request->payment_proof;
            }

            $package_payment->custom_payment_details = $request->payment_details;
            $package_payment->save();

            try {
                $notify_type = 'admin_alert';
                $id = unique_notify_id();
                $notify_by = $user->id;
                $info_id = $package_payment->id;
                $admin_title = "طلب شراء باقة جديد";
                $message = "قام العضو " . $user->first_name . ' ' . $user->last_name . " بتقديم طلب شراء باقة جديدة. رمز الدفع: " . $package_payment->payment_code;
                $route = route('package-payments.index');

                if (get_setting('firebase_push_notification') == 1) {
                    $adminTokens = User::where('user_type', 'admin')->whereNotNull('fcm_token')->pluck('fcm_token');
                    foreach ($adminTokens as $admToken) {
                        FirebaseNotificationService::sendPushNotification($admToken, $admin_title, $message, [
                            'type' => $notify_type,
                            'info_id' => $info_id,
                            'route' => $route
                        ]);
                    }
                }
                
                $adminUser = User::where('user_type', 'admin')->first();
                if($adminUser){
                    Notification::send($adminUser, new DbStoreNotification($notify_type, $id, $notify_by, $info_id, $message, $route, $admin_title));
                }
            } catch (\Exception $e) {
                // 
            }

            if ($user->email != null && get_email_template('package_purchase_email', 'status')) {
                EmailUtility::package_purchase_email($user, $package_payment);
            }

            Session::forget('payment_data');
            Session::forget('payment_type');

            flash(translate('Payment completed'))->success();
            return redirect()->route('package_payment.invoice', $package_payment->id);
        }
    }

    public function package_payment_done($payment_data, $payment_details)
    {
        $user = auth()->user();

        $package_payment = new PackagePayment();
        $package_payment->payment_code = date('ymd-His');
        $package_payment->user_id = $user->id;
        $package_payment->package_id = $payment_data['package_id'];
        $package_payment->payment_method = $payment_data['payment_method'];
        $package_payment->payment_status = 'Paid';
        $package_payment->amount = $payment_data['amount'];
        $package_payment->payment_details = $payment_details;
        $package_payment->offline_payment = 2;
        $package_payment->save();

        $member = Member::where('user_id', $user->id)->first();
        $package = Package::where('id', $payment_data['package_id'])->first();

        $member->current_package_id             = $package->id;
        // 🟢 إعجابات غير محدودة عند الشراء المباشر (-1)
        $member->remaining_interest             = -1;
        $member->remaining_photo_gallery        = $member->remaining_photo_gallery + $package->photo_gallery;
        $member->remaining_contact_view         = $member->remaining_contact_view + $package->contact;
        $member->remaining_profile_viewer_view  = $member->remaining_profile_viewer_view + $package->profile_viewers_view;
        $member->remaining_profile_image_view   = $member->remaining_profile_image_view + $package->profile_image_view;
        $member->remaining_gallery_image_view   = $member->remaining_gallery_image_view + $package->gallery_image_view;
        $member->auto_profile_match             = 1;

        // 🟢 حساب تاريخ الانتهاء بناءً على اليوم إذا انتهت الباقة السابقة
        $base_date = ($member->package_validity && strtotime($member->package_validity) > strtotime(date('Y-m-d'))) 
            ? $member->package_validity 
            : date('Y-m-d');

        $member->package_validity = date('Y-m-d', strtotime($base_date . ' +' . $package->validity . ' days'));

        if ($member->save()) {
            $user->membership = 2;
            $user->save();

            // 👑 تحديد ما إذا كانت الباقة المشتراة هي باقة VIP
            $is_vip = ($package->id == 4 || $package->amount == 50 || str_contains(strtolower($package->name), 'vip'));

            // الإشعار الحصري للعميل المرفق بإشارة VIP
            try {
                $client_title = "تفعيل الباقة";
                $client_message = "تمت إضافة " . $package->name . " لحسابك بنجاح! يمكنك الآن المراسلة والاستفادة من كافة ميزات التطبيق فوراً.";

                if (get_setting('firebase_push_notification') == 1 && !empty($user->fcm_token)) {
                    FirebaseNotificationService::sendPushNotification($user->fcm_token, $client_title, $client_message, [
                        'type' => 'package',
                        'info_id' => $package_payment->id,
                        'is_vip_package' => $is_vip ? 1 : 0,
                        'route' => ''
                    ]);
                }

                Notification::send($user, new DbStoreNotification('package', unique_notify_id(), $user->id, $package_payment->id, $client_message, '', $client_title));

            } catch (\Exception $e) {
                // Ignore
            }

            if (addon_activation('referral_system') && $user->referred_by != null && $user->referral_comission == 0) {
                $reffered_by = User::where('id', $user->referred_by)->first();
                if ($reffered_by) {
                    $wallet = new Wallet();
                    $wallet->user_id = $reffered_by->id;
                    $wallet->amount = get_setting('referred_by_user_commission');
                    $wallet->payment_method = 'reffered_commission';
                    $wallet->payment_details = '';
                    $wallet->referral_user = $user->id;
                    $wallet->save();

                    $reffered_by->balance = $reffered_by->balance + get_setting('referred_by_user_commission');
                    $reffered_by->save();

                    $user->referral_comission = 1;
                    $user->save();
                }
            }

            if ($user->email != null && get_email_template('package_purchase_email', 'status')) {
                EmailUtility::package_purchase_email($user, $package_payment);
            }
        }

        Session::forget('payment_data');
        Session::forget('payment_type');

        flash(translate('Payment completed'))->success();
        return redirect()->route('package_payment.invoice', $package_payment->id);
    }

    public function package_purchase_history(Request $request)
    {
        $package_payments = PackagePayment::latest()
            ->where('user_id', Auth::user()->id)
            ->paginate(10);
        return view('frontend.member.package_payment_history', compact('package_payments'));
    }

    public function package_payment_invoice($id)
    {
        $payment = PackagePayment::findOrFail($id);
        return view('frontend.member.payment_invoice', compact('payment'));
    }

    public function package_payment_invoice_admin($id)
    {
        $payment = PackagePayment::findOrFail($id);
        return view('admin.package_payments.payment_invoice', compact('payment'));
    }

    public function show($id)
    {
        $package_payment = PackagePayment::findOrFail($id);
        return view('admin.package_payments.payment_details', compact('package_payment'));
    }

    public function edit($id)
    {
        //
    }

    /**
     * الموافقة اليدوية (من لوحة التحكم - الشام كاش)
     */
    public function manual_payment_accept($id)
    {
        $package_payment    = PackagePayment::findOrFail($id);
        $user               = User::where('id', $package_payment->user_id)->first();
        $member             = Member::where('user_id', $user->id)->first();
        $package            = Package::where('id', $package_payment->package_id)->first();

        $member->current_package_id             = $package->id;
        // 🟢 تفعيل الإعجابات اللامحدودة للشاب المشترك (-1)
        $member->remaining_interest             = -1; 
        $member->remaining_photo_gallery        = $member->remaining_photo_gallery + $package->photo_gallery;
        $member->remaining_contact_view         = $member->remaining_contact_view + $package->contact;
        $member->remaining_profile_viewer_view  = $member->remaining_profile_viewer_view + $package->profile_viewers_view;
        $member->remaining_profile_image_view   = $member->remaining_profile_image_view + $package->profile_image_view;
        $member->remaining_gallery_image_view   = $member->remaining_gallery_image_view + $package->gallery_image_view;
        $member->auto_profile_match             = 1;

        // 🟢 حساب تاريخ الانتهاء بناءً على تاريخ اليوم إذا انتهت الباقة السابقة
        $base_date = ($member->package_validity && strtotime($member->package_validity) > strtotime(date('Y-m-d'))) 
            ? $member->package_validity 
            : date('Y-m-d');

        $member->package_validity = date('Y-m-d', strtotime($base_date . ' +' . $package->validity . ' days'));

        if ($member->save()) {
            $package_payment->payment_status = 'Paid';
            $package_payment->save();

            $user->membership = 2;
            $user->save();

            // 👑 تحديد ما إذا كانت الباقة المعتمدة هي باقة VIP
            $is_vip = ($package->id == 4 || $package->amount == 50 || str_contains(strtolower($package->name), 'vip'));

            // الإشعار بالكلمات المطلوبة تماماً للعضو مع إشعار تطبيق الموبايل بالـ VIP
            try {
                $notify_title = "تفعيل الباقة";
                $message = "تمت إضافة " . $package->name . " لحسابك بنجاح! يمكنك الآن المراسلة والاستفادة من كافة ميزات التطبيق فوراً.";

                if (get_setting('firebase_push_notification') == 1 && !empty($user->fcm_token)) {
                    FirebaseNotificationService::sendPushNotification($user->fcm_token, $notify_title, $message, [
                        'type' => 'package',
                        'info_id' => $package_payment->id,
                        'is_vip_package' => $is_vip ? 1 : 0,
                        'route' => ''
                    ]);
                }

                Notification::send($user, new DbStoreNotification('package', unique_notify_id(), $user->id, $package_payment->id, $message, '', $notify_title));

            } catch (\Exception $e) {
                // Ignore
            }

            if (addon_activation('referral_system') && $user->referred_by != null && $user->referral_comission == 0) {
                $reffered_by = User::where('id', $user->referred_by)->first();
                if ($reffered_by) {
                    $wallet = new Wallet();
                    $wallet->user_id = $reffered_by->id;
                    $wallet->amount = get_setting('referred_by_user_commission');
                    $wallet->payment_method = 'reffered_commission';
                    $wallet->referral_user = $user->id;
                    $wallet->save();

                    $reffered_by->balance = $reffered_by->balance + get_setting('referred_by_user_commission');
                    $reffered_by->save();

                    $user->referral_comission = 1;
                    $user->save();
                }
            }

            if ($user->email != null && get_email_template('manual_payment_approval_email', 'status')) {
                EmailUtility::manual_payment_approval_email($user, $package_payment);
            }

            if ($user->phone != null && addon_activation('otp_system') && get_sms_template('manual_payment_approval', 'status')) {
                SmsUtility::manual_payment_approval($user, $package_payment);
            }
        }

        flash(translate('Payemnt accepted successfully.'))->success();
        return back();
    }

    /**
     * الرفض اليدوي (من لوحة التحكم)
     */
    public function manual_payment_reject(Request $request, $id)
    {
        $package_payment    = PackagePayment::findOrFail($id);
        $user               = User::where('id', $package_payment->user_id)->first();
        $package            = Package::where('id', $package_payment->package_id)->first();

        $package_payment->payment_status = 'Rejected';
        $package_payment->save();

        try {
            $reject_title = "رفض طلب الاشتراك";
            $message = "عذراً، تم رفض طلبك للاشتراك في باقة " . $package->name . ". السبب: " . $request->reject_reason;

            if (get_setting('firebase_push_notification') == 1 && !empty($user->fcm_token)) {
                FirebaseNotificationService::sendPushNotification($user->fcm_token, $reject_title, $message, [
                    'type' => 'payment_rejected',
                    'info_id' => $package_payment->id,
                    'route' => ''
                ]);
            }

            Notification::send($user, new DbStoreNotification('payment_rejected', unique_notify_id(), null, $package_payment->id, $message, '', $reject_title));
        } catch (\Exception $e) {
            // Ignore
        }

        flash('تم رفض الحوالة وإرسال السبب للعضو بنجاح.')->success();
        return back();
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}