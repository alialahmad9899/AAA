<?php

namespace App\Services;

use App\Models\ChatThread;
use App\Models\ExpressInterest;
use App\Models\User;
use App\Notifications\DbStoreNotification;
use App\Services\FirebaseNotificationService;
use App\Utility\EmailUtility;
use App\Utility\MemberUtility;
use App\Utility\SmsUtility;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Notification;

/**
 * ============================================================================
 * اسم الملف: app/Services/InterestService.php
 * الوصف: خدمة إدارة طلبات الإعجاب، قبولها، رفضها، وربط المحادثات المباشرة والإشعارات
 * ============================================================================
 */
class InterestService
{
    /**
     * 🟢 1. إنشاء وحفظ طلب إعجاب جديد مع إرسال الإشعارات الآمنة
     * 
     * @param int $user_id معرّف العضو المستهدف بالاهتمام
     * @return bool نجاح أو فشل العملية
     */
    public function store($user_id)
    {
        try {
            $interested_by_user = auth()->user();
            if (!$interested_by_user) {
                return false;
            }

            $interested_by_member = $interested_by_user->member;

            // التحقق من إمكانية إبداء الإعجاب
            if (MemberUtility::can_express_interest($interested_by_user->id)) {

                // إنشاء وحفظ سجل الإعجاب الجديد
                $express_interest                = new ExpressInterest();
                $express_interest->user_id       = $user_id;
                $express_interest->interested_by = $interested_by_user->id;
                $express_interest->save();

                // 🟢 خصم حصة الإعجابات فقط إذا كان المستخدم ذكراً يملك باقة ورصيداً متبقياً
                if (!MemberUtility::is_female($interested_by_user->id) && $interested_by_member) {
                    if ($interested_by_member->remaining_interest > 0) {
                        $interested_by_member->remaining_interest -= 1;
                        $interested_by_member->save();
                    }
                }

                // إرسال الإشعارات للطرف المستهدف
                $notify_user = User::find($user_id);
                if ($notify_user) {
                    $notify_type = 'express_interest';
                    $notify_by   = $interested_by_user->id;
                    $info_id     = $express_interest->id;
                    $message     = $interested_by_user->first_name . ' ' . $interested_by_user->last_name . ' ' . translate(' has Expressed Interest On You.');
                    $route       = route('interest_requests');

                    // إرسال إشعارات التنبيه (Push & DB)
                    $this->notifyUser($user_id, $notify_user, $notify_type, $notify_by, $info_id, $message, $route);

                    // إرسال بريد إلكتروني مع التغليف الآمن
                    if ($notify_user->email != null && get_email_template('email_on_express_interest', 'status')) {
                        try {
                            EmailUtility::email_on_request($notify_user, 'email_on_express_interest');
                        } catch (\Exception $e) {
                            Log::error("❌ [Email Send Error]: " . $e->getMessage());
                        }
                    }

                    // إرسال رسالة SMS مع التغليف الآمن
                    if ($notify_user->phone != null && addon_activation('otp_system') && (get_sms_template('express_interest', 'status') == 1)) {
                        try {
                            SmsUtility::sms_on_request($notify_user, 'express_interest');
                        } catch (\Exception $e) {
                            Log::error("❌ [SMS Send Error]: " . $e->getMessage());
                        }
                    }
                }

                return true;
            }

            return false;
        } catch (\Exception $e) {
            Log::error("❌ [InterestService Store Error]: " . $e->getMessage());
            return false;
        }
    }

    /**
     * 🟢 2. قبول طلب الإعجاب وفتح مسار محادثة تلقائياً
     * 
     * @param int $interest_id معرّف سجل الإعجاب
     * @return bool نجاح أو فشل التفعيل
     */
    public function accept($interest_id)
    {
        try {
            $interest = ExpressInterest::find($interest_id);
            if ($interest) {
                // تحديث حالة الطلب إلى مقبول (1)
                $interest->status = 1;
                $interest->save();

                // التحقق من عدم وجود محادثة سابقة بين الطرفين
                $existing_chat_thread = ChatThread::where(function ($query) use ($interest) {
                    $query->where('sender_user_id', $interest->interested_by)
                          ->where('receiver_user_id', $interest->user_id);
                })->orWhere(function ($query) use ($interest) {
                    $query->where('receiver_user_id', $interest->interested_by)
                          ->where('sender_user_id', $interest->user_id);
                })->first();

                // إن لم توجد محادثة، يتم إنشاؤها فورياً
                if ($existing_chat_thread == null) {
                    $chat_thread                   = new ChatThread();
                    $chat_thread->thread_code      = $interest->interested_by . date('Ymd') . $interest->user_id;
                    $chat_thread->sender_user_id   = $interest->interested_by;
                    $chat_thread->receiver_user_id = $interest->user_id;
                    $chat_thread->save();
                }

                // إشعار مُرسل الإعجاب الأصلي بالقبول
                $notify_user = User::find($interest->interested_by);
                if ($notify_user) {
                    $notify_type = 'accept_interest';
                    $notify_by   = auth()->user()->id;
                    $info_id     = $interest->id;
                    $message     = auth()->user()->first_name . ' ' . auth()->user()->last_name . ' ' . translate(' has accepted your interest.');
                    $route       = route('my_interests.index');

                    $this->notifyUser($interest->interested_by, $notify_user, $notify_type, $notify_by, $info_id, $message, $route);

                    if ($notify_user->email != null && get_email_template('email_on_accepting_interest', 'status')) {
                        try {
                            EmailUtility::email_on_accept_request($notify_user, 'email_on_accepting_interest');
                        } catch (\Exception $e) {
                            Log::error("❌ [Email Accept Send Error]: " . $e->getMessage());
                        }
                    }

                    if ($notify_user->phone != null && addon_activation('otp_system') && (get_sms_template('accept_interest', 'status') == 1)) {
                        try {
                            SmsUtility::sms_on_accept_request($notify_user, 'accept_interest');
                        } catch (\Exception $e) {
                            Log::error("❌ [SMS Accept Send Error]: " . $e->getMessage());
                        }
                    }
                }

                return true;
            }

            return false;
        } catch (\Exception $e) {
            Log::error("❌ [InterestService Accept Error]: " . $e->getMessage());
            return false;
        }
    }

    /**
     * 🟢 3. رفض طلب الإعجاب وحذفه
     * 
     * @param int $interest_id معرّف سجل الإعجاب
     * @return bool نجاح أو فشل الحذف
     */
    public function reject($interest_id)
    {
        try {
            $interest = ExpressInterest::find($interest_id);
            if ($interest) {
                $interested_by = $interest->interested_by;
                ExpressInterest::destroy($interest_id);

                $notify_user = User::find($interested_by);
                if ($notify_user) {
                    $notify_type = 'reject_interest';
                    $notify_by   = auth()->user()->id;
                    $info_id     = $interest_id;
                    $message     = auth()->user()->first_name . ' ' . auth()->user()->last_name . ' ' . translate(' has rejected your interest.');
                    $route       = route('my_interests.index');

                    $this->notifyUser($interested_by, $notify_user, $notify_type, $notify_by, $info_id, $message, $route);
                }

                return true;
            }

            return false;
        } catch (\Exception $e) {
            Log::error("❌ [InterestService Reject Error]: " . $e->getMessage());
            return false;
        }
    }

    /**
     * 🟢 4. إرسال الإشعارات الفورية وتخزينها في قاعدة البيانات وFirebase بأعلى كفاءة
     */
    public function notifyUser($user_id, $notify_user, $notify_type, $notify_by, $info_id, $message, $route)
    {
        try {
            $id    = unique_notify_id();
            $title = $this->getNotificationTitle($notify_type);

            // 1. إرسال إشعار Firebase Push
            if ($notify_user && !empty($notify_user->fcm_token)) {
                try {
                    FirebaseNotificationService::sendPushNotification(
                        $notify_user->fcm_token,
                        $title,
                        $message
                    );
                } catch (\Exception $e) {
                    Log::error("❌ [Firebase Notification Error]: " . $e->getMessage());
                }
            }

            // 2. حفظ الإشعار في قاعدة البيانات
            if ($notify_user) {
                try {
                    Notification::send($notify_user, new DbStoreNotification($notify_type, $id, $notify_by, $info_id, $message, $route, $title));
                } catch (\Exception $e) {
                    Log::error("❌ [DbStoreNotification Error]: " . $e->getMessage());
                }
            }

            return true;
        } catch (\Exception $e) {
            Log::error("❌ [InterestService NotifyUser Error]: " . $e->getMessage());
            return false;
        }
    }

    /**
     * 🟢 5. جلب عنوان الإشعار بحسب نوعه
     */
    private function getNotificationTitle($type)
    {
        switch ($type) {
            case 'express_interest':
                return 'إعجاب جديد ✨';
            case 'accept_interest':
                return 'تم قبول الإعجاب 🎉';
            case 'reject_interest':
                return 'تحديث طلب الإعجاب';
            default:
                return 'إشعار جديد من وصال';
        }
    }
}