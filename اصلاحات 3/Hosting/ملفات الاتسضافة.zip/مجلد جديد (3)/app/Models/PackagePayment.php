<?php

namespace App\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PackagePayment extends Model
{
    use SoftDeletes;

    public function user()
    {
        return $this->belongsTo(User::class)->withTrashed();
    }

    public function package()
    {
        return $this->belongsTo(Package::class)->withTrashed();
    }

    /**
     * 🟢 علاقة تربط سجل عملية الدفع باستبيان باقة الـ VIP المرفق بها
     */
    public function vipSurvey()
    {
        return $this->hasOne(VipSurvey::class, 'package_payment_id');
    }
}