@extends('frontend.layouts.app')

@section('content')
<style>
    /* === التنسيقات الملكية لصفحة الدعم الفني (Royal Contact Theme) === */
    .contact-wrapper { 
        background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%) !important;
        min-height: 100vh;
        font-family: 'Cairo', sans-serif;
    }

    .royal-glass-card { 
        border: none; 
        border-radius: 24px; 
        background: rgba(255, 255, 255, 0.95) !important; 
        backdrop-filter: blur(20px) saturate(160%);
        -webkit-backdrop-filter: blur(20px) saturate(160%);
        border: 1px solid rgba(212, 175, 55, 0.4);
        box-shadow: 0 25px 50px rgba(0,0,0,0.3);
        overflow: hidden;
    }
    
    .card-body { padding: 3rem 2.5rem !important; }

    /* التنبيه الصارم (Anti-Dating Warning) */
    .strict-warning-banner {
        background: #fffbeb;
        border: 2px dashed #f59e0b;
        border-radius: 16px;
        padding: 20px;
        margin-bottom: 30px;
        display: flex;
        align-items: center;
        gap: 15px;
        box-shadow: 0 5px 15px rgba(245, 158, 11, 0.1);
    }
    .strict-warning-banner i {
        color: #f59e0b;
        font-size: 40px;
    }
    .strict-warning-text h6 {
        color: #b45309;
        font-weight: 900;
        font-size: 16px;
        margin-bottom: 5px;
    }
    .strict-warning-text p {
        color: #78350f;
        font-weight: 700;
        font-size: 14px;
        margin-bottom: 0;
        line-height: 1.6;
    }

    /* العناوين */
    .icon-circle-royal {
        width: 80px;
        height: 80px;
        background: linear-gradient(135deg, var(--primary), var(--hov-primary));
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 20px;
        box-shadow: 0 8px 20px rgba(212, 175, 55, 0.4);
    }

    @keyframes textShineGold {
        0% { color: var(--secondary); text-shadow: 0 0 5px rgba(212, 175, 55, 0); }
        50% { color: var(--primary); text-shadow: 0 0 20px rgba(212, 175, 55, 0.6); }
        100% { color: var(--secondary); text-shadow: 0 0 5px rgba(212, 175, 55, 0); }
    }
    .shiny-title {
        animation: textShineGold 4s infinite ease-in-out;
        font-weight: 900 !important;
        font-size: 1.8rem;
    }

    /* الحقول */
    .form-label {
        color: var(--secondary) !important;
        font-weight: 800;
        font-size: 15px;
        margin-bottom: 8px;
    }
    .royal-input { 
        border-radius: 12px !important; 
        padding: 0.85rem 1.2rem !important; 
        border: 2px solid rgba(15, 23, 42, 0.08) !important; 
        background-color: #f8fafc !important;
        color: var(--secondary) !important;
        font-weight: 700;
        transition: all 0.3s;
    }
    .royal-input:focus { 
        background-color: #ffffff !important;
        border-color: var(--primary) !important;
        box-shadow: 0 0 0 4px rgba(212, 175, 55, 0.15) !important;
    }
    .form-text {
        font-weight: 600;
        font-size: 12px;
        color: #64748b;
        margin-top: 5px;
    }

    /* زر الإرسال */
    .btn-royal-submit { 
        background: linear-gradient(135deg, var(--primary), var(--hov-primary)) !important;
        color: #ffffff !important;
        padding: 1rem !important; 
        border-radius: 12px !important; 
        font-weight: 900 !important; 
        font-size: 16px;
        border: none !important;
        box-shadow: 0 8px 20px rgba(212, 175, 55, 0.3);
        transition: all 0.3s ease;
    }
    .btn-royal-submit:hover { 
        transform: translateY(-3px); 
        box-shadow: 0 12px 25px rgba(212, 175, 55, 0.4);
    }

    @media (max-width: 768px) {
        .card-body { padding: 2rem 1.5rem !important; }
        .strict-warning-banner { flex-direction: column; text-align: center; gap: 10px; }
    }
</style>

<div class="contact-wrapper py-5 text-right" dir="rtl">
    <div class="container">
        <div class="row">
            <div class="col-xxl-6 col-xl-7 col-lg-8 mx-auto">
                <div class="card royal-glass-card">
                    <div class="card-body">
                        
                        {{-- الهيدر --}}
                        <div class="text-center mb-4">
                            <div class="icon-circle-royal">
                                <i class="las la-headset la-4x text-white"></i>
                            </div>
                            <h2 class="shiny-title">{{ translate('Can we help you?') }}</h2>
                            <p class="text-muted fw-700 fs-15 mt-2">فريق الدعم الفني متواجد دائماً لمساعدتك وحل مشاكلك</p>
                        </div>

                        {{-- 🛑 البنر التحذيري الصارم 🛑 --}}
                        <div class="strict-warning-banner">
                            <i class="las la-exclamation-triangle"></i>
                            <div class="strict-warning-text">
                                <h6>تنبيه إداري هام!</h6>
                                <p>هذه الصفحة مخصصة <strong>فقط</strong> للإبلاغ عن المشاكل التقنية، الدفع، أو الشكاوى ضد حسابات مسيئة. <br> <span style="color: #dc2626; font-weight: 900;">لا تقم بإرسال طلبات زواج أو تعارف هنا، الإدارة لا تتدخل في الاختيارات الشخصية للأعضاء!</span></p>
                            </div>
                        </div>

                        @if ($errors->any())
                            <div class="alert alert-danger" style="border-radius: 12px; font-weight: 700;">
                                <ul class="mb-0 pr-3">
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif

                        <form action="{{ route('contact-us.store') }}" method="post" id="contact-form">
                            @csrf
                            
                            <div class="row">
                                <div class="col-md-6 mb-4">
                                    <label class="form-label"> {{ translate('Name') }} <span class="text-danger">*</span> </label>
                                    <input type="text" class="form-control royal-input" name="name" placeholder="الاسم الكامل" required>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <label class="form-label"> {{ translate('Email') }} <span class="text-danger">*</span></label>
                                    <input type="email" class="form-control royal-input" name="email" placeholder="البريد الإلكتروني" required>
                                    <div class="form-text">سيتم إرسال الرد على هذا البريد.</div>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label class="form-label"> نوع المشكلة (الموضوع) <span class="text-danger">*</span> </label>
                                <input type="text" class="form-control royal-input" name="subject" placeholder="مثال: مشكلة في الدفع، تبليغ عن عضو، خطأ في الموقع..." required>
                            </div>

                            <div class="mb-4">
                                <label class="form-label"> {{ translate('Description') }} <span class="text-danger">*</span> </label>
                                <textarea class="form-control royal-input" rows="6" placeholder="اشرح مشكلتك بالتفصيل هنا ليتمكن فريق الدعم من مساعدتك..." name="description" required style="resize: none; height: auto !important;"></textarea>
                            </div>

                            @if(get_setting('google_recaptcha_activation') == 1 && get_setting('recaptcha_user_register') == 1)
                                <div class="mb-4 d-flex justify-content-center">
                                    @if ($errors->has('g-recaptcha-response'))
                                        <span class="border invalid-feedback rounded p-2 mb-3 bg-danger text-white fw-700" role="alert" style="display: block;">
                                            <strong>{{ $errors->first('g-recaptcha-response') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            @endif

                            <div class="mt-2">
                                <button type="submit" class="btn btn-block btn-royal-submit">
                                    <i class="las la-paper-plane mr-2 fs-20"></i> إرسال البلاغ للإدارة
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
	@if(get_setting('google_recaptcha_activation') == 1 && get_setting('recaptcha_contact_form') == 1)
		@include('partials.recaptcha', ['action' => 'recaptcha_contact_form','form_id' => 'contact-form'])
	@endif
@endsection