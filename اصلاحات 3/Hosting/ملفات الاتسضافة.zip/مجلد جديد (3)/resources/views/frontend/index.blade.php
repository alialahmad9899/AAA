@extends('frontend.layouts.app')
@section('content')

{{-- بداية قسم السلايدر الرئيسي (الصور المتحركة في أعلى الصفحة) --}}
@if (get_setting('show_homepage_slider') == 'on' && get_setting('home_slider_images') != null)
<section class="position-relative overflow-hidden min-vh-100 d-flex home-slider-area">
    @php
    $slider_images = json_decode(get_setting('home_slider_images'), true);
    $slider_images_small = json_decode(get_setting('home_slider_images_small'), true);
    @endphp
    <div class="absolute-full">
        <div class="aiz-carousel aiz-carousel-full h-100 d-none {{ get_setting('home_slider_images_small') != null ? 'd-md-block' : 'd-block' }}"
            data-fade='true' data-infinite='true' data-autoplay='true'>
            @foreach ($slider_images as $key => $slider_image)
            <img class="img-fit" src="{{ uploaded_asset($slider_image) }}">
            @endforeach
        </div>
        @if (get_setting('home_slider_images_small') != null)
        <div class="aiz-carousel aiz-carousel-full h-100 d-md-none" data-fade='true' data-infinite='true'
            data-autoplay='true'>
            @foreach ($slider_images_small as $key => $slider_image)
            <img class="img-fit" src="{{ uploaded_asset($slider_image) }}">
            @endforeach
        </div>
        @endif

    </div>
    <div class="container position-relative d-flex flex-column">
        <div class="row pt-11 pb-8 my-auto align-items-center">
            <div class="col-xl-5 col-lg-6">
                <div class="text-dark home-slider-text">
                    {!! get_setting('home_slider_text') !!}
                </div>
            </div>

            @if (!Auth::check() && get_setting('show_homepage_slider_registration') == 'on')

{{-- بداية دالة زر فتح نموذج تسجيل الدخول والتسجيل الجانبي المحدثة كلياً --}}
<style>
    /* 1. تأثير النص اللامع باللون الذهبي */
    @keyframes textShineGold {
        0% { color: #000000; text-shadow: 0 0 5px rgba(212, 175, 55, 0); }
        50% { color: var(--primary); text-shadow: 0 0 15px rgba(212, 175, 55, 0.5); }
        100% { color: #000000; text-shadow: 0 0 5px rgba(212, 175, 55, 0); }
    }
    .shiny-title {
        animation: textShineGold 3s infinite ease-in-out;
        font-weight: 900 !important;
    }

    /* 2. الخلفية الزجاجية الفاخرة للحاوية */
    .form-slide-wrapper {
        background: rgba(255, 255, 255, 0.6) !important; 
        backdrop-filter: blur(25px) saturate(180%);
        -webkit-backdrop-filter: blur(25px) saturate(180%);
        border-left: 1px solid rgba(255, 255, 255, 0.5);
        box-shadow: -10px 0 40px rgba(15, 23, 42, 0.15);
    }

    /* 3. زر الإرسال الذهبي الملكي */
    .glass-submit-btn {
        background: linear-gradient(135deg, var(--primary) 0%, var(--hov-primary) 100%) !important;
        border: none !important;
        color: #ffffff !important;
        font-weight: 800 !important;
        border-radius: 12px !important;
        transition: all 0.4s ease;
        box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
    }
    .glass-submit-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(212, 175, 55, 0.5);
    }

    /* 4. خيارات الاختيار الكبير (Selection Cards) */
    .auth-choice-card {
        background: rgba(255, 255, 255, 0.8);
        border: 1px solid rgba(212, 175, 55, 0.2);
        border-radius: 15px;
        padding: 25px;
        margin-bottom: 20px;
        cursor: pointer;
        transition: 0.3s;
        text-align: center;
    }
    .auth-choice-card:hover {
        background: #ffffff;
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(15, 23, 42, 0.1);
        border-color: var(--primary);
    }
    .auth-choice-card i {
        font-size: 40px;
        margin-bottom: 10px;
        color: var(--primary);
    }
    .auth-choice-card h4 {
        font-weight: 800;
        color: var(--secondary);
        margin-bottom: 5px;
    }

    /* 5. زر العودة للخلف */
    .back-to-choice {
        color: var(--secondary);
        font-weight: 800;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        margin-bottom: 20px;
        transition: 0.3s;
    }
    .back-to-choice:hover { color: var(--primary); }

    /* 6. إجبار كافة النصوص الداخلية على الأسود القاتم أو الكحلي */
    #register-form-container label, 
    #register-form-container p, 
    #register-form-container span:not(.white-text):not(.text-danger) {
        color: var(--secondary) !important;
        font-weight: 700;
    }

    /* 7. زر الإغلاق (X) */
    .close-registration-btn svg {
        fill: var(--secondary) !important;
        transition: transform 0.3s ease;
    }
    .close-registration-btn:hover svg { transform: rotate(90deg); fill: var(--primary) !important; }

    /* 8. تنسيق المواليد */
    .mini-dob-group { display: flex; gap: 4px; justify-content: space-between; }
    .mini-dob-group .bootstrap-select { flex: 1 !important; min-width: 0; }
    .mini-dob-group .btn.dropdown-toggle {
        padding: 4px 4px !important;
        height: 45px !important;
        border-radius: 10px !important;
        background: rgba(255,255,255,0.9) !important;
        border: 1px solid rgba(15, 23, 42, 0.1) !important;
    }
    .mini-dob-group .filter-option-inner-inner {
        font-size: 14px !important; 
        font-weight: 800 !important;
        text-align: center !important;
        color: var(--secondary) !important;
    }

    .form-control {
        height: 45px;
        border-radius: 10px;
        border: 1px solid rgba(15, 23, 42, 0.1);
        font-weight: 600;
        color: var(--secondary);
    }
    .form-control:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 0.2rem rgba(212, 175, 55, 0.25);
    }

    @media (max-width: 768px) {
        .card-body { padding: 1.5rem !important; }
        .form-slide-wrapper { width: 100% !important; }
    }
</style>

<div class="offset-xxl-2 offset-xl-1 col-lg-6 col-xxl-5 position-relative">
    {{-- الزر الخارجي الملون والنابض --}}
    <button type="button" class="account-btn animated-btn" id="show-register-form">
        <span class="border-anim top" style="background: var(--secondary) !important;"></span>
        <span class="border-anim right" style="background: var(--secondary) !important;"></span>
        <span class="border-anim bottom" style="background: var(--secondary) !important;"></span>
        <span class="border-anim left" style="background: var(--secondary) !important;"></span>

        <div class="text-center">
            <div class="big-title shiny-title">إنشاء حسابك الخاص</div>
            <div class="sub-title" style="color: var(--secondary) !important;">ابدأ رحلتك معنا اليوم</div>
        </div>
    </button>

    {{-- حاوية النموذج الجانبي --}}
    <div id="register-form-container" class="form-slide-wrapper">
        <div class="card h-100 border-0 bg-transparent">
            <div class="card-body p-4 p-lg-5">
                {{-- زر إشارة إكس (X) للإغلاق --}}
                <button type="button" id="close-register-form"
                    class="close-registration-btn btn p-0 border-0 bg-transparent position-absolute start-0 m-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 485.34 485.34">
                        <path d="M254.67-237.33l-17.34-17.34L462.67-480,237.33-705.33l17.34-17.34L480-497.33,705.33-722.67l17.34,17.34L497.33-480,722.67-254.67l-17.34,17.34L480-462.67Z"
                            transform="translate(-237.33 722.67)" />
                    </svg>
                </button>

                <div class="mt-5"></div> 

                {{-- الشاشة الأولى: شاشة الاختيار --}}
                <div id="auth-selection-view" class="text-center">
                    <div class="mb-5">
                        <h3 class="shiny-title mb-2">أهلاً بك في وصال</h3>
                        <p style="color: var(--secondary);">يرجى تحديد وجهتك للمتابعة</p>
                    </div>

                    <div class="auth-choice-card" onclick="showAuthView('login')">
                        <i class="las la-user-check"></i>
                        <h4>لدي حساب بالفعل</h4>
                        <p class="small text-muted">سجل دخولك لمتابعة محادثاتك</p>
                    </div>

                    <div class="auth-choice-card" onclick="showAuthView('register')">
                        <i class="las la-user-plus"></i>
                        <h4>أنا مستخدم جديد</h4>
                        <p class="small text-muted">أنشئ حسابك وابحث عن شريك حياتك</p>
                    </div>
                </div>

                {{-- الشاشة الثانية: نموذج تسجيل الدخول (مخفي) --}}
                <div id="login-view" class="d-none">
                    <div class="back-to-choice" onclick="showAuthView('selection')">
                        <i class="las la-arrow-right ml-2"></i> العودة للخلف
                    </div>
                    <h3 class="mb-4 fw-900" style="color: var(--secondary);">تسجيل الدخول</h3>
                    <form action="{{ route('login') }}" method="POST">
                        @csrf
                        <input type="checkbox" name="remember" checked style="display:none;">
                        <div class="form-group mb-3">
                            <label class="form-label">البريد الألكتروني الذي تم التسجيل فيه</label>
                            <input type="text" name="email" class="form-control" placeholder="أدخل الايميل" required>
                            </div>
                        <div class="form-group mb-4">
                            <label class="form-label">كلمة المرور</label>
                            <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                        </div>
                        <button type="submit" class="btn btn-block glass-submit-btn py-3 fs-16 shadow-lg">دخول سريع</button>
                    </form>
                </div>

                {{-- الشاشة الثالثة: نموذج إنشاء الحساب (مخفي) --}}
                <div id="register-view" class="d-none">
                    <div class="back-to-choice" onclick="showAuthView('selection')">
                        <i class="las la-arrow-right ml-2"></i> العودة للخلف
                    </div>
                    
                    <form class="form-default" id="reg-form" role="form" action="{{ route('register') }}" method="POST">
                        @csrf
                        <input type="checkbox" name="remember" checked style="display:none;">

                        @php $on_behalves = \App\Models\OnBehalf::all(); @endphp
                        @if ($on_behalves->isNotEmpty())
                        <div class="form-group mb-3">
                            <label class="form-label">صاحب الحساب</label>
                            <select class="form-control aiz-selectpicker" name="on_behalf" required>
                                @foreach ($on_behalves as $on_behalf)
                                <option value="{{ $on_behalf->id }}">{{ $on_behalf->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        @endif

                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group mb-3">
                                    <label class="form-label">الاسم الأول</label>
                                    <input type="text" class="form-control" name="first_name" placeholder="الاسم" required>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group mb-3">
                                    <label class="form-label">الكنية</label>
                                    <input type="text" class="form-control" name="last_name" placeholder="الكنية" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group mb-3">
                                    <label class="form-label">الجنس</label>
                                    <select id="gender" class="form-control aiz-selectpicker" name="gender" required>
                                        <option value="1">ذكر</option>
                                        <option value="2">أنثى</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group mb-3">
                                    <label class="form-label">
                                        تاريخ الميلاد
                                        <span class="text-danger" style="font-size: 10px; display: block;">(إجباري للمتابعة)</span>
                                    </label>
                                    <input type="hidden" id="date_of_birth" name="date_of_birth">
                                    <div class="mini-dob-group">
                                        <select id="side_day" class="form-control aiz-selectpicker" title="يوم">
                                            <option value="" selected disabled>يوم</option>
                                            @for ($i = 1; $i <= 31; $i++) <option value="{{ sprintf('%02d', $i) }}">{{ $i }}</option> @endfor
                                        </select>
                                        <select id="side_month" class="form-control aiz-selectpicker" title="شهر">
                                            <option value="" selected disabled>شهر</option>
                                            @for ($m = 1; $m <= 12; $m++) <option value="{{ sprintf('%02d', $m) }}">{{ $m }}</option> @endfor
                                        </select>
                                        <select id="side_year" class="form-control aiz-selectpicker" title="سنة">
                                            <option value="" selected disabled>سنة</option>
                                            @for ($y = date('Y') - 18; $y >= date('Y') - 70; $y--) <option value="{{ $y }}">{{ $y }}</option> @endfor
                                        </select>
                                    </div>
                                    <small id="dob-error" class="text-danger d-none" style="font-weight: 800;">يرجى اختيار التاريخ!</small>
                                </div>
                            </div>
                        </div>

                        @if (addon_activation('otp_system'))
                        <div id="emailOrPhoneDiv">
                            <div class="d-flex justify-content-between mb-1">
                                <label class="form-label">الهاتف أو البريد</label>
                                <button class="btn btn-link p-0 fs-11 fw-700" style="color: var(--primary);" type="button" onclick="toggleEmailPhone(this)">تبديل الوسيلة</button>
                            </div>
                            <div class="form-group phone-form-group mb-3">
                                <input type="number" class="form-control" placeholder="رقم الموبايل" name="phone">
                            </div>
                            <div class="form-group email-form-group mb-3 d-none">
                                <input type="email" class="form-control" placeholder="البريد الإلكتروني" name="email">
                            </div>
                        </div>
                        @else
                        <div class="form-group mb-3">
                            <label class="form-label">البريد الإلكتروني</label>
                            <input type="email" class="form-control" name="email" placeholder="example@mail.com" required>
                        </div>
                        @endif

                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group mb-3">
                                    <label class="form-label">كلمة المرور</label>
                                    <input type="password" class="form-control" name="password" required>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group mb-3">
                                    <label class="form-label">تأكيد المرور</label>
                                    <input type="password" class="form-control" name="password_confirmation" required>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="aiz-checkbox">
                                <input type="checkbox" name="checkbox_example_1" required>
                                <span class="fs-13">أوافق على <a href="{{ env('APP_URL').'/terms-conditions' }}" target="_blank" class="fw-800 underline" style="color: var(--primary);">الشروط</a>.</span>
                                <span class="aiz-square-check"></span>
                            </label>
                        </div>

                        <button type="button" id="createAccountBtnManual" class="btn btn-block glass-submit-btn py-3 fs-16 shadow-lg">إنشاء الحساب الآن</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // دالة التحكم في الشاشات
    function showAuthView(view) {
        const selection = document.getElementById('auth-selection-view');
        const login = document.getElementById('login-view');
        const register = document.getElementById('register-view');

        // إخفاء الكل أولاً
        selection.classList.add('d-none');
        login.classList.add('d-none');
        register.classList.add('d-none');

        // إظهار المطلوب
        if (view === 'selection') selection.classList.remove('d-none');
        if (view === 'login') login.classList.remove('d-none');
        if (view === 'register') register.classList.remove('d-none');
    }

    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('close-register-form').addEventListener('click', function() {
            setTimeout(() => { showAuthView('selection'); }, 500);
        });

        const d = document.getElementById('side_day');
        const m = document.getElementById('side_month');
        const y = document.getElementById('side_year');
        const hidden = document.getElementById('date_of_birth');
        const err = document.getElementById('dob-error');
        const btn = document.getElementById('createAccountBtnManual');
        const form = document.getElementById('reg-form');

        function sync() { 
            if(d.value && m.value && y.value) {
                hidden.value = y.value + '-' + m.value + '-' + d.value;
                err.classList.add('d-none');
            } else { hidden.value = ''; }
        }
        
        [d, m, y].forEach(el => el.addEventListener('change', sync));

        btn.addEventListener('click', function() {
            sync();
            if(!hidden.value) {
                err.classList.remove('d-none');
                document.querySelector('.mini-dob-group').style.border = "1px solid red";
                setTimeout(() => { document.querySelector('.mini-dob-group').style.border = "none"; }, 2000);
            } else {
                form.submit();
            }
        });
    });
</script>
            @endif
        </div>
{{-- نهاية قسم البحث السريع الزجاجي الفاخر المحسن --}}

{{-- بداية قسم البحث السريع الزجاجي العريض مع العنوان الملفت --}}
@if (Auth::check() && Auth::user()->user_type == 'member')
    <style>
        .glass-search-section {
            position: relative;
            z-index: 20;
            margin-top: -100px; 
            padding: 0 15px;
        }

        .glass-search-wrapper {
            background: rgba(255, 255, 255, 0.5); 
            backdrop-filter: blur(25px) saturate(200%);
            -webkit-backdrop-filter: blur(25px) saturate(200%);
            border-radius: 30px;
            border: 1px solid rgba(255, 255, 255, 0.8);
            box-shadow: 0 25px 50px rgba(15, 23, 42, 0.1);
            padding: 50px 40px 40px 40px; 
            width: 100%;
            max-width: 1300px; 
            margin: 0 auto;
        }

        .eye-catcher-title {
            position: absolute;
            top: -20px;
            right: 40px;
            background: linear-gradient(135deg, var(--secondary) 0%, var(--primary) 100%);
            color: #fff;
            padding: 10px 30px;
            border-radius: 50px;
            font-weight: 800;
            font-size: 18px;
            box-shadow: 0 10px 20px rgba(15, 23, 42, 0.3);
            display: flex;
            align-items: center;
            gap: 10px;
            z-index: 5;
            border: 2px solid #fff;
            animation: pulse-glow-gold 2s infinite;
        }

        @keyframes pulse-glow-gold {
            0% { box-shadow: 0 0 0 0 rgba(212, 175, 55, 0.7); }
            70% { box-shadow: 0 0 0 15px rgba(212, 175, 55, 0); }
            100% { box-shadow: 0 0 0 0 rgba(212, 175, 55, 0); }
        }

        .luxury-input {
            border-radius: 15px !important;
            border: 1px solid rgba(15, 23, 42, 0.1) !important;
            height: 55px !important;
            font-weight: 700 !important;
            font-size: 15px !important;
            background: rgba(255, 255, 255, 0.9) !important;
            color: var(--secondary) !important;
        }

        .luxury-input:focus {
            background: #fff !important;
            border-color: var(--primary) !important;
            box-shadow: 0 0 15px rgba(212, 175, 55, 0.2) !important;
        }

        .btn-search-luxury {
            background: linear-gradient(45deg, var(--primary), var(--hov-primary));
            color: #fff !important;
            height: 55px;
            border-radius: 15px;
            font-weight: 800;
            border: none;
            font-size: 17px;
            transition: all 0.3s ease;
            box-shadow: 0 8px 20px rgba(212, 175, 55, 0.3);
        }

        .btn-search-luxury:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 25px rgba(212, 175, 55, 0.5);
        }

        .search-label {
            font-weight: 800;
            color: var(--secondary);
            font-size: 14px;
            margin-bottom: 12px;
            display: block;
            margin-right: 5px;
        }

        @media (max-width: 991px) {
            .glass-search-section { margin-top: -60px; }
            .eye-catcher-title { 
                right: 50%; 
                transform: translateX(50%); 
                font-size: 14px; 
                padding: 8px 20px;
                white-space: nowrap;
            }
            .glass-search-wrapper { padding: 40px 20px 20px 20px; }
        }
    </style>

    <div class="glass-search-section">
        <div class="glass-search-wrapper text-right" dir="rtl">
            
            {{-- الجملة الملفتة للنظر --}}
            <div class="eye-catcher-title">
                <i class="las la-heartbeat fs-24"></i>
                ابحث عن شريك حياتك الآن
            </div>

            <form action="{{ route('member.listing') }}" method="get">
                <div class="row gutters-15 align-items-end">
                    
                    {{-- العمر من --}}
                    <div class="col-xl-2 col-lg-2 col-6">
                        <div class="form-group mb-3 mb-xl-0">
                            <label class="search-label">العمر من</label>
                            <input type="number" name="age_from" class="form-control luxury-input" placeholder="20">
                        </div>
                    </div>

                    {{-- العمر إلى --}}
                    <div class="col-xl-2 col-lg-2 col-6">
                        <div class="form-group mb-3 mb-xl-0">
                            <label class="search-label">إلى عمر</label>
                            <input type="number" name="age_to" class="form-control luxury-input" placeholder="40">
                        </div>
                    </div>

                    {{-- الديانة --}}
                    <div class="col-xl-3 col-lg-3 col-12">
                        <div class="form-group mb-3 mb-xl-0">
                            <label class="search-label">الديانة</label>
                            @php $religions = \App\Models\Religion::all(); @endphp
                            <select name="religion_id" class="form-control luxury-input aiz-selectpicker" data-live-search="true">
                                <option value="">كل الديانات</option>
                                @foreach ($religions as $religion)
                                    <option value="{{ $religion->id }}">{{ $religion->name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    {{-- بلد الإقامة --}}
                    <div class="col-xl-3 col-lg-3 col-12">
                        <div class="form-group mb-3 mb-xl-0">
                            <label class="search-label">بلد الإقامة</label>
                            @php $countries = \App\Models\Country::all(); @endphp
                            <select name="country_id" class="form-control luxury-input aiz-selectpicker" data-live-search="true">
                                <option value="">كل الدول</option>
                                @foreach ($countries as $country)
                                    <option value="{{ $country->id }}">{{ $country->name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    {{-- زر البحث العريض --}}
                    <div class="col-xl-2 col-lg-2 col-12">
                        <button type="submit" class="btn btn-block btn-search-luxury">
                            <i class="las la-search fs-20"></i> ابحث الآن
                        </button>
                    </div>

                </div>
            </form>
        </div>
    </div>
@endif
{{-- نهاية قسم البحث السريع الزجاجي العريض --}}
</section>
@endif
{{-- نهاية قسم السلايدر الرئيسي --}}


{{-- 🛑 🛑 🛑 بداية قسم الأعضاء المتصلين الآن (Online Members) 🛑 🛑 🛑 --}}
@if (Auth::check() && Auth::user()->user_type == 'member')
    @php
        // جلب جنس العضو الحالي ليتم عرض الجنس المعاكس فقط
        $my_gender = Auth::user()->member ? Auth::user()->member->gender : 1; 
        $target_gender = ($my_gender == 1) ? 2 : 1;

        // جلب الأعضاء اللي كانوا متصلين خلال آخر 10 دقائق (باستخدام نظام الكاش)
        $active_users = \App\Models\User::where('user_type', 'member')
            ->where('approved', 1)
            ->where('blocked', 0)
            ->where('deactivated', 0)
            ->where('id', '!=', Auth::user()->id)
            ->whereHas('member', function($q) use ($target_gender) {
                $q->where('gender', $target_gender); // فلترة لعرض الجنس المعاكس فقط
            });
            
        // سحب أحدث 12 عضو تم تسجيل اتصالهم
        $online_members = $active_users->get()->filter(function($user) {
            return \Cache::has('user-is-online-' . $user->id);
        })->take(12);
    @endphp

    <style>
        .online-members-wrapper {
            background-color: #f8fafc;
            padding: 60px 0 40px 0;
        }
        
        .online-pulse {
            position: absolute;
            top: 5px;
            left: 5px;
            width: 14px;
            height: 14px;
            background-color: #10b981; /* أخضر متصل */
            border-radius: 50%;
            border: 2px solid #fff;
            box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7);
            animation: pulse-green 1.5s infinite;
            z-index: 10;
        }
        @keyframes pulse-green {
            0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }
            70% { transform: scale(1); box-shadow: 0 0 0 10px rgba(16, 185, 129, 0); }
            100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
        }

        .online-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--primary);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.2);
            transition: 0.3s;
        }
        
        .online-member-card {
            text-align: center;
            padding: 10px;
            transition: 0.3s;
            display: block;
            text-decoration: none !important;
        }
        .online-member-card:hover .online-avatar {
            transform: translateY(-5px);
            border-color: var(--secondary);
        }
        
        .online-name {
            margin-top: 10px;
            font-size: 13px;
            font-weight: 800;
            color: var(--secondary);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
    </style>

    <section class="online-members-wrapper text-right" dir="rtl">
        <div class="container">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h3 class="fw-900 m-0" style="color: var(--secondary); font-size: 22px;">
                    <i class="las la-wifi" style="color: #10b981;"></i> متواجدون الآن
                </h3>
                <a href="{{ route('member.listing') }}" class="text-primary fw-800 text-decoration-none" style="font-size: 14px;">عرض الجميع <i class="las la-angle-left"></i></a>
            </div>

            @if($online_members->count() > 0)
                <div class="aiz-carousel gutters-10 half-outside-arrow" 
                    data-items="8" 
                    data-xl-items="6"
                    data-lg-items="5" 
                    data-md-items="4" 
                    data-sm-items="3" 
                    data-xs-items="3" 
                    data-dots='false'
                    data-infinite='false'
                    data-autoplay='false'>
                    
                    @foreach($online_members as $online_member)
                        <div class="carousel-box">
                            <a href="{{ route('member_profile', $online_member->id) }}" class="online-member-card">
                                <div class="position-relative d-inline-block">
                                    @php
                                        $avatar = 'assets/img/avatar-place.png';
                                        if($online_member->member && $online_member->member->gender == 2){
                                            $avatar = 'assets/img/female-avatar-place.png';
                                        }
                                    @endphp
                                    <img src="{{ uploaded_asset($online_member->photo) }}" onerror="this.onerror=null;this.src='{{ static_asset($avatar) }}';" class="online-avatar">
                                    <span class="online-pulse" title="متصل الآن"></span>
                                </div>
                                <div class="online-name">{{ $online_member->first_name }}</div>
                            </a>
                        </div>
                    @endforeach
                </div>
            @else
                <div class="text-center py-5 rounded-lg" style="background: rgba(15, 23, 42, 0.02); border: 1px dashed rgba(15, 23, 42, 0.05); border-radius: 15px;">
                    <div class="size-60px rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3" style="background: #fff; box-shadow: 0 5px 15px rgba(0,0,0,0.05);">
                        <i class="las la-user-clock la-2x text-muted"></i>
                    </div>
                    <h5 class="fw-800" style="color: var(--secondary);">لا يوجد أعضاء متصلين حالياً</h5>
                    <p class="text-muted fw-600 mb-0 fs-14">يمكنك الضغط على عرض الجميع لعرض كافة الاعضاء.</p>
                </div>
            @endif
        </div>
    </section>
@endif
{{-- 🛑 🛑 🛑 نهاية قسم الأعضاء المتصلين 🛑 🛑 🛑 --}}


{{-- بداية قسم الأعضاء المميزين - اللمسة الذهبية الناعمة والفخمة --}}
@if (get_setting('show_premium_member_section') == 'on')
<style>
    .premium-gold-wrapper .carousel-box img {
        border-radius: 50% !important; 
        aspect-ratio: 1 / 1; 
        object-fit: cover;
        padding: 4px !important;
        background: linear-gradient(135deg, var(--primary), var(--hov-primary)) !important;
        box-shadow: 0 10px 30px rgba(212, 175, 55, 0.15) !important;
        transition: all 0.5s cubic-bezier(0.165, 0.84, 0.44, 1);
        margin: 0 auto !important;
    }

    .premium-gold-wrapper .carousel-box:hover img {
        transform: translateY(-5px) scale(1.02);
        box-shadow: 0 15px 35px rgba(212, 175, 55, 0.3) !important;
    }

    .premium-gold-wrapper .carousel-box h6 {
        font-weight: 800 !important;
        color: var(--secondary) !important;
        margin-top: 15px !important;
        transition: color 0.3s ease;
    }
    .premium-gold-wrapper .carousel-box:hover h6 {
        color: var(--primary) !important;
    }

    .premium-gold-wrapper .section-title h2 {
        color: var(--secondary);
        font-weight: 900;
        letter-spacing: -0.5px;
    }
    .premium-gold-wrapper .section-title h2::after {
        content: "";
        display: block;
        width: 80px;
        height: 4px;
        background: linear-gradient(90deg, transparent, var(--primary), transparent);
        margin: 15px auto 0;
        border-radius: 2px;
    }

    .premium-gold-wrapper .carousel-box {
        position: relative;
        padding-top: 10px; 
    }
    .premium-gold-wrapper .carousel-box::before {
        content: "\f521"; 
        font-family: "Line Awesome Free";
        font-weight: 900;
        position: absolute;
        top: 15px;
        right: 15px; 
        background: linear-gradient(135deg, var(--primary), var(--hov-primary));
        color: #fff;
        width: 32px;
        height: 32px;
        line-height: 28px;
        text-align: center;
        border-radius: 50%;
        z-index: 5;
        border: 2px solid #ffffff;
        box-shadow: 0 5px 15px rgba(212, 175, 55, 0.4);
        font-size: 15px;
        transition: all 0.4s ease;
    }
    .premium-gold-wrapper .carousel-box:hover::before {
        transform: scale(1.1) rotate(10deg);
    }
</style>

<section class="pt-7 pb-5 premium-gold-wrapper" style="background-color: var(--bg-body);">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 col-xl-8 col-xxl-6 mx-auto">
                <div class="text-center section-title mb-5">
                    <h2 class="fw-900 mb-3">{{ get_setting('premium_member_section_title') }}</h2>
                    <p class="fw-600 fs-16 opacity-60">{{ get_setting('premium_member_section_sub_title') }}</p>
                </div>
            </div>
        </div>
        
        <div class="aiz-carousel gutters-10 half-outside-arrow" 
            data-items="5" 
            data-xl-items="4"
            data-lg-items="4" 
            data-md-items="3" 
            data-sm-items="2" 
            data-xs-items="1" 
            data-dots='true'
            data-infinite='true'
            data-autoplay='true'>
            
            @foreach ($premium_members as $key => $member)
            <div class="carousel-box">
                @include('frontend.inc.member_box_1', ['member' => $member])
            </div>
            @endforeach
        </div>
    </div>
</section>
@endif
{{-- نهاية قسم الأعضاء المميزين --}}


{{-- بداية قسم البنرات الإعلانية الأولى --}}
@if (get_setting('show_home_banner1_section') == 'on' && get_setting('home_banner1_images') != null)
<section class="py-5" style="background-color: var(--bg-body);">
    <div class="container">
        <div class="row gutters-10">
            @php $banner_1_imags = json_decode(get_setting('home_banner1_images')); @endphp
            @foreach ($banner_1_imags as $key => $value)
            <div class="col-xl col-md-6">
                <div class="mb-3">
                    <a href="{{ json_decode(get_setting('home_banner1_links'), true)[$key] }}"
                        class="d-block text-reset rounded-lg overflow-hidden shadow-sm" style="transition: 0.3s;">
                        <img src="{{ static_asset('assets/img/placeholder-rect.jpg') }}"
                            data-src="{{ uploaded_asset($banner_1_imags[$key]) }}"
                            alt="{{ env('APP_NAME') }}" class="img-fluid lazyload w-100">
                    </a>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
@endif
{{-- نهاية قسم البنرات الإعلانية الأولى --}}


{{-- بداية قسم كيف يعمل الموقع - التصميم الفاخر --}}
@if (get_setting('show_how_it_works_section') == 'on')
<style>
    .how-it-works-luxury {
        background-color: #ffffff;
        padding: 90px 0;
        position: relative;
        overflow: hidden;
    }

    .journey-title {
        font-weight: 900;
        color: var(--secondary);
        margin-bottom: 15px;
    }
    .journey-divider {
        width: 70px;
        height: 4px;
        background: linear-gradient(90deg, var(--secondary), var(--primary));
        margin: 0 auto 20px;
        border-radius: 5px;
    }
    .journey-subtitle {
        font-size: 16px;
        color: #64748b;
        font-weight: 600;
        line-height: 1.6;
        max-width: 600px;
        margin: 0 auto;
    }

    .steps-wrapper {
        position: relative;
        margin-top: 50px;
    }

    .steps-connector {
        position: absolute;
        top: 45px;
        left: 15%;
        right: 15%;
        height: 0;
        border-top: 3px dashed rgba(212, 175, 55, 0.3);
        z-index: 0;
    }

    .step-luxury-card {
        background: var(--bg-body);
        border-radius: 24px;
        padding: 40px 30px;
        text-align: center;
        border: 1px solid rgba(0, 0, 0, 0.03);
        box-shadow: 0 10px 40px rgba(15, 23, 42, 0.05);
        transition: all 0.4s cubic-bezier(0.165, 0.84, 0.44, 1);
        position: relative;
        z-index: 1;
        height: 100%;
    }
    .step-luxury-card:hover {
        transform: translateY(-12px);
        box-shadow: 0 20px 50px rgba(212, 175, 55, 0.15);
        border-color: rgba(212, 175, 55, 0.3);
    }

    .step-number {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 30px;
        font-weight: 900;
        color: #fff;
        margin: 0 auto 25px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        border: 6px solid var(--bg-body);
        position: relative;
        transition: transform 0.3s;
    }
    .step-luxury-card:hover .step-number {
        transform: scale(1.1) rotate(-5deg);
    }

    /* ألوان الخطوات بتدرجات الكحلي والذهبي */
    .step-1 .step-number { background: linear-gradient(135deg, var(--secondary), #1e293b); box-shadow: 0 10px 25px rgba(15, 23, 42, 0.3); }
    .step-2 .step-number { background: linear-gradient(135deg, var(--primary), var(--hov-primary)); box-shadow: 0 10px 25px rgba(212, 175, 55, 0.4); }
    .step-3 .step-number { background: linear-gradient(135deg, #1e293b, var(--secondary)); box-shadow: 0 10px 25px rgba(15, 23, 42, 0.3); }

    .step-title {
        font-size: 20px;
        font-weight: 900;
        color: var(--secondary);
        margin-bottom: 15px;
    }
    .step-desc {
        font-size: 14.5px;
        color: #64748b;
        line-height: 1.7;
        font-weight: 600;
    }

    @media (max-width: 991px) {
        .steps-connector { display: none; }
        .step-luxury-card { margin-bottom: 30px; padding: 30px 20px; }
        .how-it-works-luxury { padding: 60px 0 30px 0; }
    }
</style>

<section class="how-it-works-luxury text-right" dir="rtl">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto text-center">
                <h2 class="journey-title">رحلتك نحو السعادة الزوجية</h2>
                <div class="journey-divider"></div>
                <p class="journey-subtitle">
                    ثلاث خطوات بسيطة وموثوقة تفصلك عن إيجاد شريك حياتك المناسب. صممنا منصتنا لتكون بيئة آمنة وراقية تساعدك على البدء بثقة ومصداقية.
                </p>
            </div>
        </div>

        <div class="steps-wrapper">
            <div class="steps-connector"></div>
            
            <div class="row gutters-20">
                <div class="col-lg-4 step-1">
                    <div class="step-luxury-card">
                        <div class="step-number"><i class="las la-user-edit"></i></div>
                        <h3 class="step-title">1. أنشئ ملفك بصدق</h3>
                        <p class="step-desc">
                            سجل حسابك مجاناً وأضف تفاصيلك ومواصفات بدقة وعناية. كلما كان ملفك الشخصي متكاملاً وصادقاً، زادت فرصتك في جذب الشريك.
                        </p>
                    </div>
                </div>

                <div class="col-lg-4 step-2">
                    <div class="step-luxury-card">
                        <div class="step-number"><i class="las la-search-heart"></i></div>
                        <h3 class="step-title">2. ابحث واكتشف التطابقات</h3>
                        <p class="step-desc">
                            استخدم خوارزميات البحث الذكية وأنظمة التطابق المتقدمة لدينا للوصول إلى الأشخاص الذين يتوافقون مع معاييرك الدينية والاجتماعية.
                        </p>
                    </div>
                </div>

                <div class="col-lg-4 step-3">
                    <div class="step-luxury-card">
                        <div class="step-number"><i class="las la-ring"></i></div>
                        <h3 class="step-title">3. تواصل وتلاقى بآمان</h3>
                        <p class="step-desc">
                            ابدأ بمراسلة من يلفت انتباهك في بيئة آمنة وتحترم الخصوصية. تواصل بكل ود واحترام وابنِ علاقة مبنية على التفاهم.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endif
{{-- نهاية قسم كيف يعمل الموقع --}}


{{-- بداية قسم إحصائيات الثقة --}}
@if (get_setting('show_trusted_by_millions_section') == 'on')
<section class="bg-center bg-cover min-vh-100 py-7 text-white d-flex align-items-center bg-fixed"
    style="background-image: url('{{ uploaded_asset(get_setting('trusted_by_millions_background_image')) }}')">
    <div class="container">
        <div class="row">
            <div class="col-xl-8 mx-auto">
                <div class="text-center pb-12">
                    <h2 class="fw-900" style="color: var(--primary);">{{ get_setting('trusted_by_millions_title') }}</h2>
                    <div class="fs-16 fw-600">{{ get_setting('trusted_by_millions_sub_title') }}</div>
                </div>
            </div>
        </div>
        <div class="row">
            @php
            $homepage_best_features = json_decode(get_setting('homepage_best_features'));
            @endphp
            @if (!empty($homepage_best_features))
            @foreach ($homepage_best_features as $key => $homepage_best_feature)
            <div class="col-lg">
                <div class="rounded position-relative z-1 border-gray-600 overflow-hidden mt-4" style="border: 1px solid rgba(212, 175, 55, 0.3);">
                    <div class="absolute-full bg-dark opacity-70 z--1"></div>
                    <div class="px-4 py-5 d-flex align-items-center justify-content-center">
                        <img src="{{ uploaded_asset(json_decode(get_setting('homepage_best_features_icons'), true)[$key]) }}"
                            class="img-fluid h-25px">
                        <span class="fs-17 ml-3 fw-700">{{ $homepage_best_feature }}</span>
                    </div>
                </div>
            </div>
            @endforeach
            @endif
        </div>
    </div>
</section>
@endif
{{-- نهاية قسم إحصائيات الثقة --}}


{{-- بداية قسم الأعضاء الجدد --}}
@if (get_setting('show_new_member_section') == 'on')
<style>
    .new-members-luxury {
        background: linear-gradient(180deg, #ffffff 0%, var(--bg-body) 100%);
        padding: 80px 0;
    }

    .new-members-title {
        font-weight: 900;
        color: var(--secondary);
        margin-bottom: 10px;
    }
    .new-members-divider {
        width: 60px;
        height: 4px;
        background: linear-gradient(90deg, var(--secondary), var(--primary));
        margin: 0 auto 20px;
        border-radius: 5px;
    }

    .new-members-luxury .carousel-box img {
        border-radius: 50% !important;
        width: 140px !important;
        height: 140px !important;
        object-fit: cover !important;
        border: 4px solid #fff !important;
        box-shadow: 0 5px 20px rgba(15, 23, 42, 0.15) !important;
        margin: 0 auto !important;
        border: 2px solid var(--primary) !important; 
    }

    .id-text-bold {
        display: block;
        color: var(--secondary) !important;
        font-weight: 900 !important;
        font-size: 15px !important;
        margin-top: 10px;
        text-align: center;
    }

    .new-members-luxury .aiz-card-box {
        border: none !important;
        background: transparent !important;
        box-shadow: none !important;
    }
</style>

<section class="new-members-luxury text-center" dir="rtl">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 col-xl-8 mx-auto">
                <div class="mb-5">
                    <h2 class="new-members-title">أعضاء انضموا إلينا حديثاً</h2>
                    <div class="new-members-divider"></div>
                    <p class="fs-16 text-muted fw-600">
                        نرحب يومياً بوجوه جديدة تبحث عن الاستقرار وبناء عائلة سعيدة. بادر بالتواصل الآن، فقد يكون شريك حياتك بانتظارك هنا.
                    </p>
                </div>
            </div>
        </div>

        <div class="aiz-carousel gutters-10 half-outside-arrow" 
            data-items="5" 
            data-xl-items="4"
            data-lg-items="4" 
            data-md-items="3" 
            data-sm-items="2" 
            data-xs-items="1" 
            data-dots='true'
            data-infinite='true'
            data-autoplay='true'>
            
            @foreach ($new_members as $key => $member)
                <div class="carousel-box">
                    <div class="position-relative">
                        @include('frontend.inc.member_box_1', ['member' => $member])
                        
                        <span class="id-text-bold">
                              ID: {{ $member->user->code ?? $member->user->id ?? '' }}
                        </span>
                    </div>
                </div>
            @endforeach
        </div>

        <div class="mt-5">
            <a href="{{ route('member.listing') }}" class="btn btn-primary rounded-pill px-5 fw-800 shadow-sm" style="height: 48px; line-height: 34px;">
                اكتشف جميع المنضمين الجدد
            </a>
        </div>
    </div>
</section>
@endif
{{-- نهاية قسم الأعضاء الجدد --}}


{{-- بداية قسم قصص النجاح السعيدة --}}
@if (get_setting('show_happy_story_section') == 'on')
<section class="py-7 text-white" style="background: linear-gradient(135deg, var(--secondary) 0%, #1e293b 100%);">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 col-xl-8 col-xxl-6 mx-auto">
                <div class="text-center section-title mb-5">
                    <h2 class="fw-900 mb-3" style="color: var(--primary);">Happy Stories</h2>
                    <div style="width: 60px; height: 3px; background: var(--primary); margin: 0 auto;"></div>
                </div>
            </div>
        </div>
        <div class="card-columns column-gap-10 card-columns-xxl-4 card-columns-lg-3 card-columns-md-2 card-columns-1">
            @php
            $happy_stories = \App\Models\HappyStory::where('approved', '1')
            ->latest()
            ->limit(get_setting('max_happy_story_show_homepage'))
            ->get();
            @endphp
            @foreach ($happy_stories as $key => $happy_story)
            @php
            $photo = explode(',', $happy_story->photos);
            @endphp
            <div class="card border-0 overflow-hidden mb-3 shadow-lg" style="border-radius: 15px;">
                <a href="{{ route('story_details', $happy_story->id) }}"
                    class="text-reset d-block position-relative">
                    <img src="{{ uploaded_asset($photo[0]) }}" class="img-fluid w-100" style="object-fit: cover; aspect-ratio: 4/3;">
                    <div class="absolute-bottom-left p-3 w-100">
                        <div class="position-relative z-1 p-3 rounded" style="background: rgba(15, 23, 42, 0.85); backdrop-filter: blur(5px); border-left: 3px solid var(--primary);">
                            <div class="text-primary-grad text-truncate fw-800 mb-1">
                                {{ $happy_story->user->first_name . ' & ' . $happy_story->partner_name }}
                            </div>
                            <h2 class="h5 mb-0 fs-14 fw-600 lh-1-5 text-truncate-2 text-white">
                                {{ $happy_story->title }}
                            </h2>
                        </div>
                    </div>
                </a>
            </div>
            @endforeach
        </div>
        <div class="text-center mt-5">
            <a href="{{ route('happy_stories') }}" class="btn btn-outline-primary rounded-pill px-5 py-2 fw-800">{{ translate('View More') }}</a>
        </div>
    </div>
</section>
@endif
{{-- نهاية قسم قصص النجاح السعيدة --}}

{{-- بداية قسم باقات الاشتراك --}}
@if (get_setting('show_homapege_package_section') == 'on')
<style>
    .home-packages-section {
        background-color: var(--bg-body);
        padding: 90px 0;
    }
    .luxury-package-card {
        background: #fff;
        border-radius: 24px;
        overflow: hidden;
        border: 1px solid rgba(0,0,0,0.03);
        box-shadow: 0 10px 40px rgba(15, 23, 42, 0.05);
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        position: relative;
        height: 100%;
        display: flex;
        flex-direction: column;
        margin: 15px 10px;
    }
    .luxury-package-card:hover {
        transform: translateY(-12px);
        box-shadow: 0 20px 50px rgba(212, 175, 55, 0.15);
        border-color: var(--primary);
    }
    .package-img-header {
        width: 100%;
        height: 170px;
        object-fit: cover;
        border-bottom: 4px solid var(--primary);
        transition: 0.5s;
    }
    .luxury-package-card:hover .package-img-header {
        transform: scale(1.05);
    }
    .package-name-badge {
        position: absolute;
        top: 150px;
        left: 50%;
        transform: translateX(-50%);
        background: linear-gradient(45deg, var(--secondary), #1e293b);
        color: var(--primary);
        padding: 8px 25px;
        border-radius: 25px;
        font-weight: 900;
        font-size: 16px;
        box-shadow: 0 5px 15px rgba(15, 23, 42, 0.4);
        white-space: nowrap;
        z-index: 2;
        border: 1px solid rgba(212, 175, 55, 0.3);
    }
    .package-features-list {
        list-style: none;
        padding: 0;
        margin: 45px 0 20px 0;
        flex-grow: 1;
        text-align: right;
    }
    .package-features-list li {
        padding: 12px 20px;
        border-bottom: 1px dashed rgba(15, 23, 42, 0.05);
        font-size: 14px;
        font-weight: 700;
        color: #475569;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .package-features-list li:last-child { border-bottom: none; }
    
    .feature-item-title {
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .feature-item-title i { font-size: 20px; color: var(--primary); }
    
    .quota-number-bold {
        color: var(--secondary) !important;
        font-weight: 900 !important;
        font-size: 15px;
    }

    .package-price-section {
        background: #f8fafc;
        padding: 25px 20px;
        text-align: center;
        border-top: 1px solid rgba(0,0,0,0.03);
    }
    .price-val {
        font-size: 32px;
        font-weight: 900;
        color: var(--secondary);
    }
    .price-days {
        font-size: 13px;
        color: #64748b;
        font-weight: 700;
        margin-top: 5px;
        margin-bottom: 15px;
    }
    .btn-upgrade {
        background: linear-gradient(45deg, var(--primary), var(--hov-primary));
        color: #fff !important;
        font-weight: 800;
        border-radius: 12px;
        padding: 12px;
        display: block;
        width: 100%;
        transition: 0.3s;
        border: none;
    }
    .btn-upgrade:hover {
        box-shadow: 0 8px 20px rgba(212, 175, 55, 0.4);
        transform: translateY(-2px);
    }

    @media (max-width: 767px) {
        .package-img-header { height: 140px; }
        .package-name-badge { top: 125px; font-size: 14px; }
    }
</style>

<section class="home-packages-section">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-900 text-dark h2" style="color: var(--secondary) !important;">باقات التميز والارتباط</h2>
            <div style="width: 60px; height: 4px; background: var(--primary); margin: 15px auto; border-radius: 10px;"></div>
            <p class="text-muted fs-16 fw-600">اختر خطتك الآن وابدأ رحلة البحث عن شريك العمر بميزات استثنائية</p>
        </div>

        <div class="aiz-carousel" 
            data-items="4" data-xl-items="3" data-md-items="2" data-sm-items="1"
            data-dots='true' data-infinite='true' data-autoplay='true'>
            
            @foreach (\App\Models\Package::where('active', '1')->get() as $key => $package)
            
            @if($package->id == 11 && (!Auth::check() || Auth::user()->member->gender != 2))
                @continue
            @endif

            <div class="carousel-box">
                <div class="luxury-package-card text-right" dir="rtl">
                    
                    <img class="package-img-header" src="{{ uploaded_asset($package->image) }}" onerror="this.onerror=null;this.src='{{ static_asset('assets/img/placeholder-rect.jpg') }}';">
                    
                    <div class="package-name-badge">{{ $package->name }}</div>
                    
                    <ul class="package-features-list">
                        <li style="background: rgba(212, 175, 55, 0.05);">
                            <span class="feature-item-title"><i class="las la-envelope-open-text"></i> عدد المحادثات:</span>
                            @if($package->message_profile_quota == -1)
                                <span class="badge px-2 py-1" style="background: var(--primary); color: #fff;">غير محدود</span>
                            @else
                                <span class="quota-number-bold">{{ $package->message_profile_quota }} محادثة</span>
                            @endif
                        </li>

                        <li>
                            <span class="feature-item-title"><i class="las la-heart"></i> إهتمام وإعجاب:</span>
                            <span class="quota-number-bold">{{ $package->express_interest }}</span>
                        </li>
                        
                        <li>
 <span class="feature-item-title"><i class="las la-phone-volume"></i> إظهار رقم الهاتف:</span>
                            <span class="quota-number-bold">{{ $package->contact }}</span>
                        </li>
                        
                        <li>
                            <span class="feature-item-title"><i class="las la-images"></i> صور المعرض:</span>
                            <span class="quota-number-bold">{{ $package->photo_gallery }}</span>
                        </li>
                        
                        <li>
                            <span class="feature-item-title"><i class="las la-robot"></i> التطابق الذكي:</span>
                            @if( $package->auto_profile_match == 0 )
                                <i class="las la-times-circle text-danger fs-22"></i>
                            @else
                                <i class="las la-check-circle text-success fs-22"></i>
                            @endif
                        </li>
                    </ul>

                    <div class="package-price-section">
                        @if ($package->id == 1 || $package->id == 11)
                            <div class="price-val" style="color: #10b981;">مجاناً</div>
                        @else
                            <div class="price-val">{{ single_price($package->price) }}</div>
                        @endif
                        <div class="price-days">صالحة لمدة {{ $package->validity }} يوماً</div>
                        
                        <div class="mt-2">
                            @if ($package->id != 1 && $package->id != 11)
                                @if(Auth::check())
                                    <a href="{{ route('package_payment_methods', encrypt($package->id)) }}" class="btn-upgrade">
                                        <i class="las la-shopping-cart"></i> اشترك الآن
                                    </a>
                                @else
                                    <button onclick="loginModal()" class="btn-upgrade">
                                        <i class="las la-sign-in-alt"></i> سجل للشراء
                                    </button>
                                @endif
                            @else
                                <button class="btn btn-light w-100 fw-800 rounded-pill" disabled style="height: 45px;">باقة مجانية</button>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
@endif
{{-- نهاية قسم باقات الاشتراك --}}

{{-- بداية قسم المدونة والمقالات --}}
@if (get_setting('show_blog_section') == 'on')
<style>
    .luxury-blog-section {
        background-color: #ffffff;
        padding: 90px 0;
    }
    
    .blog-header h2 {
        font-weight: 900;
        color: var(--secondary);
    }
    .blog-header .divider {
        width: 70px;
        height: 4px;
        background: linear-gradient(90deg, var(--secondary), var(--primary));
        margin: 15px auto 30px;
        border-radius: 10px;
    }

    .blog-card-custom {
        background: var(--bg-body);
        border-radius: 20px;
        overflow: hidden;
        border: 1px solid rgba(0,0,0,0.03);
        box-shadow: 0 10px 30px rgba(15, 23, 42, 0.05);
        transition: all 0.4s ease;
        height: 100%;
        display: flex;
        flex-direction: column;
    }
    .blog-card-custom:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(212, 175, 55, 0.15);
        border-color: rgba(212, 175, 55, 0.2);
    }

    .blog-image-wrap {
        position: relative;
        height: 220px;
        overflow: hidden;
    }
    .blog-image-wrap img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.6s ease;
    }
    .blog-card-custom:hover .blog-image-wrap img {
        transform: scale(1.1);
    }

    .blog-cat-badge {
        position: absolute;
        bottom: 15px;
        right: 15px;
        background: rgba(15, 23, 42, 0.85);
        color: var(--primary);
        padding: 4px 15px;
        border-radius: 50px;
        font-size: 12px;
        font-weight: 800;
        backdrop-filter: blur(5px);
        border: 1px solid rgba(212, 175, 55, 0.3);
    }

    .blog-content {
        padding: 25px;
        flex-grow: 1;
        display: flex;
        flex-direction: column;
    }

    .blog-title-link {
        font-size: 18px;
        font-weight: 900;
        color: var(--secondary);
        line-height: 1.5;
        margin-bottom: 15px;
        transition: 0.3s;
        display: block;
        text-decoration: none !important;
    }
    .blog-title-link:hover {
        color: var(--primary);
    }

    .blog-description {
        color: #64748b;
        font-size: 14px;
        line-height: 1.7;
        margin-bottom: 20px;
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
        font-weight: 600;
    }

    .btn-read-more {
        margin-top: auto;
        color: var(--primary);
        font-weight: 900;
        font-size: 14px;
        display: flex;
        align-items: center;
        gap: 5px;
        text-decoration: none !important;
        transition: 0.3s;
    }
    .btn-read-more:hover {
        gap: 10px;
        color: var(--secondary);
    }

    .btn-view-all {
        background: #fff;
        color: var(--secondary);
        border: 2px solid var(--primary);
        padding: 12px 40px;
        border-radius: 50px;
        font-weight: 800;
        transition: 0.3s;
    }
    .btn-view-all:hover {
        background: var(--primary);
        color: #fff;
        box-shadow: 0 10px 20px rgba(212, 175, 55, 0.3);
    }
</style>

<section class="luxury-blog-section text-right" dir="rtl">
    <div class="container">
        <div class="blog-header text-center mb-5">
            <h2 class="h2">{{ get_setting('blog_section_title') }}</h2>
            <div class="divider"></div>
            <p class="text-muted fs-16 fw-600">مقالات ونصائح تهمك في رحلة البحث عن شريك الحياة وبناء علاقة زوجية ناجحة</p>
        </div>

        <div class="aiz-carousel gutters-15" data-items="4" data-xl-items="3" data-md-items="2" data-sm-items="1" data-arrows='true' data-autoplay='true'>
            @php
                $blogs = \App\Models\Blog::query()
                    ->where('status', 1)
                    ->latest()
                    ->limit(get_setting('max_blog_show_homepage'))
                    ->get();
            @endphp
            
            @foreach ($blogs as $key => $blog)
            <div class="carousel-box p-2">
                <div class="blog-card-custom">
                    <div class="blog-image-wrap">
                        <a href="{{ route('blog.details', $blog->slug) }}">
                            <img src="{{ uploaded_asset($blog->banner) }}" alt="{{ $blog->title }}">
                        </a>
                        @if ($blog->category != null)
                            <span class="blog-cat-badge">{{ $blog->category->category_name }}</span>
                        @endif
                    </div>
                    
                    <div class="blog-content">
                        <a href="{{ route('blog.details', $blog->slug) }}" class="blog-title-link">
                            {{ $blog->title }}
                        </a>
                        
                        <p class="blog-description">
                            {{ $blog->short_description }}
                        </p>
                        
                        <a href="{{ route('blog.details', $blog->slug) }}" class="btn-read-more">
                            اقرأ المزيد <i class="las la-long-arrow-left"></i>
                        </a>
                    </div>
                </div>
            </div>
            @endforeach
        </div>

        <div class="text-center mt-5">
            <a href="{{ route('blog') }}" class="btn-view-all">
                مشاهدة جميع المقالات
            </a>
        </div>
    </div>
</section>
@endif

{{-- بداية قسم تقييمات الأعضاء --}}
@if (get_setting('show_homepage_review_section') == 'on' && get_setting('homepage_reviews') != null)
<style>
    .luxury-reviews-section {
        padding: 90px 0;
        background: linear-gradient(180deg, var(--bg-body) 0%, #ffffff 100%);
    }
    .review-glass-card {
        background: rgba(255, 255, 255, 0.6) !important;
        backdrop-filter: blur(15px);
        -webkit-backdrop-filter: blur(15px);
        border: 1px solid rgba(212, 175, 55, 0.2);
        border-radius: 20px;
        padding: 40px;
        box-shadow: 0 10px 40px rgba(15, 23, 42, 0.08);
        margin: 10px 15px;
    }
    
    .review-text { color: var(--secondary) !important; font-weight: 700; font-style: italic; line-height: 1.8; }
    .rating-stars { color: var(--primary); font-size: 20px; margin-bottom: 15px; }
</style>

<section class="luxury-reviews-section text-center" dir="rtl">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 col-xl-9 col-xxl-6 mx-auto">
                <div class="text-center mb-5">
                    <div class="royal-black-strip" style="background: var(--secondary); padding: 10px 30px; border-radius: 12px; display: inline-block; border: 1px solid rgba(212, 175, 55, 0.3);">
                        <h2 class="h3 mb-0" style="color: var(--primary) !important; font-weight: 900;">{{ get_setting('homepage_review_section_title') }}</h2>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-xxl-10 mx-auto">
                <div class="aiz-carousel large-arrow" data-items="1" data-arrows='true' data-infinite='true' data-autoplay='true'>
                    @php
                        $homepage_reviews = json_decode(get_setting('homepage_reviews'), true);
                        $reviewers_images = json_decode(get_setting('homepage_reviewers_images'), true);
                    @endphp
                    
                    @foreach ($homepage_reviews as $key => $review)
                    <div class="carousel-box">
                        <div class="review-glass-card text-center px-lg-9">
                            <img src="{{ uploaded_asset($reviewers_images[$key]) }}" 
                                 onerror="this.onerror=null;this.src='{{ static_asset('assets/img/avatar-place.png') }}';" 
                                 class="size-180px img-fit mx-auto rounded-circle border border-width-5 shadow-lg mb-4" style="border-color: var(--primary) !important;">
                                 
                            <div class="rating-stars">
                                <i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i>
                            </div>
                            
                            <div class="fs-18 fw-700 font-italic text-dark mb-3">"{{ $review }}"</div>
                            <i class="las la-quote-right la-4x opacity-20" style="color: var(--primary);"></i>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</section>
@endif

@endsection

@section('modal')
@include('modals.login_modal')
@include('modals.package_update_alert_modal')
@endsection

@section('script')
    <script type="text/javascript">
        function loginModal() {
            $('#LoginModal').modal();
        }

        function package_update_alert() {
            $('.package_update_alert_modal').modal('show');
        }
    </script>
    @if (get_setting('google_recaptcha_activation') == 1 && get_setting('recaptcha_user_register') == 1 && !auth()->check())
        @include('partials.recaptcha', ['action' => 'recaptcha_user_register', 'form_id' => 'reg-form'])
    @endif
    @if (addon_activation('otp_system'))
        @include('partials.emailOrPhone')
    @endif

    @if (get_setting('registration_verification'))
        @include('partials.verifyEmailOrPhone')
    @endif

<script>
    const showBtn = document.getElementById('show-register-form');
    const formContainer = document.getElementById('register-form-container');
    const closeBtn = document.getElementById('close-register-form');

    showBtn.addEventListener('click', function () {
        formContainer.style.display = 'block'; 
        void formContainer.offsetWidth; 
        formContainer.classList.add('active'); 
        showBtn.style.display = 'none';
    });

    closeBtn.addEventListener('click', closeSidebar);

    function closeSidebar() {
        formContainer.classList.remove('active'); 
        setTimeout(() => {
            formContainer.style.display = 'none'; 
            showBtn.style.display = 'block';
        }, 500); 
    }

    document.addEventListener('DOMContentLoaded', function() {
        const select = document.getElementById('gender');
        const dobInput = document.getElementById("date_of_birth"); 

        function initDatepicker(maxDate) {
            if ($(dobInput).data('daterangepicker')) {
                $(dobInput).data('daterangepicker').remove();
            }
            $(dobInput).daterangepicker({
                singleDatePicker: $(dobInput).data('single') ?? true,
                showDropdowns: $(dobInput).data('show-dropdown') ?? true,
                maxDate: maxDate,
                startDate: maxDate, 
                autoUpdateInput: true,
                locale: {
                    format: $(dobInput).data('format') || 'YYYY-MM-DD',
                    applyLabel: "Select",
                    cancelLabel: "Clear",
                },
            });
            dobInput.value = maxDate;
        }
        initDatepicker(select.options[select.selectedIndex].getAttribute('startdate'));
        select.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const maxDate = selectedOption.getAttribute('startdate');
            dobInput.setAttribute('data-max-date', maxDate);
            initDatepicker(maxDate);
        });

    });

</script>


@if ($errors->any())
<script>
    window.addEventListener('DOMContentLoaded', function () {
        const formContainer = document.getElementById('register-form-container');
        const showBtn = document.getElementById('show-register-form');
        formContainer.style.display = 'block';
        void formContainer.offsetWidth
        formContainer.classList.add('active');
        if (showBtn) {
            showBtn.style.display = 'none';
        }
    });
</script>
@endif

<script type="text/javascript">
    const regVerifyRequired = {{get_setting('registration_verification') ? 'true' : 'false' }};
    const createBtn   = $('#createAccountBtn');
    const termsCheckbox = $('input[name="checkbox_example_1"]');
    function toggleCreateBtn() {
        const termsChecked = termsCheckbox.is(':checked');
        const regVerified  = regVerifyRequired ? (verifyBtn && verifyBtn.classList.contains('disabled')) : true;
        let enableBtn = false;
        if (regVerifyRequired) {
            enableBtn = termsChecked && regVerified;
        } else {
            enableBtn = termsChecked;
        }
        createBtn.prop('disabled', !enableBtn);
    }

    document.addEventListener('DOMContentLoaded', function() {
        toggleCreateBtn();                                      
        termsCheckbox.on('change', toggleCreateBtn); 
    });
</script>
@endsection